# ============================================================
# TRIWORX + GUI SAFE WRAPPER (FINAL, PATH‑SAFE)
# ============================================================

import argparse
import os
import sys
import shutil
import subprocess
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


import sys
print("[WRAPPER] argv =", sys.argv)
print("[WRAPPER] module imported, __name__ =", __name__)

# ============================================================
# COMMON HELPERS
# ============================================================

def _script_path(script_name: str) -> str:
    """
    Resolve pipeline scripts from either:
      - tools_pipeline/Stage1_Tools/<script>
      - tools_pipeline/<script>   (fallback)
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))  # Stage1_Tools
    parent_dir = os.path.dirname(base_dir)                 # tools_pipeline

    candidates = [
        os.path.join(base_dir, script_name),
        os.path.join(parent_dir, script_name),
    ]

    for p in candidates:
        if os.path.exists(p):
            return p

    raise RuntimeError(f"Pipeline script not found: {script_name}")


def run_blackbox_cli(script_name: str, args: list[str]):
    sp = _script_path(script_name)
    cmd = [sys.executable, sp] + args
    print("[TriWorX] RUN:", " ".join(cmd))

    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(
            f"{script_name} failed:\n"
            f"STDOUT:\n{res.stdout}\n"
            f"STDERR:\n{res.stderr}"
        )
    if res.stdout.strip():
        print(res.stdout.strip())


def generate_output_file_cli(test_plan: str, test_exec_keys: str) -> str:
    today = datetime.now().strftime("%d_%m_%Y")
    te = test_exec_keys.split(",")[0].strip()
    return os.path.abspath(
        f"C:/JLR/Tools/TriWorX_Full/Generated_L0_TriageFiles"
        f"L0_Triage_Report_{today}_TP_{test_plan}_TE_{te}.xlsx"
    )


# ============================================================
# CLI MODE (USED BY TRIWORX STAGE‑1)
# ============================================================

def run_triworx_cli():
    parser = argparse.ArgumentParser("TriWorX Stage‑1 Wrapper (CLI)")

    parser.add_argument("--template_file", required=True)
    parser.add_argument("--test_execution", required=True)
    parser.add_argument("--test_plan", required=True)
    parser.add_argument("--execution_type", required=True, choices=["MANUAL", "AUTOMATED"])

    parser.add_argument("--manual_input_file")
    parser.add_argument("--sw_version")
    parser.add_argument("--rig_id")
    parser.add_argument("--sw_component")

    parser.add_argument("--output_file")

    args = parser.parse_args()

    execution_type = args.execution_type.upper()

    output_file = (
        os.path.abspath(args.output_file)
        if args.output_file
        else generate_output_file_cli(args.test_plan, args.test_execution)
    )

    print("[TriWorX] Stage 1 Using output file:", output_file)

    if not os.path.exists(args.template_file):
        raise RuntimeError(f"Template file not found: {args.template_file}")

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    if not os.path.exists(output_file):
        shutil.copyfile(args.template_file, output_file)

    if execution_type == "MANUAL":
        if not args.manual_input_file:
            raise RuntimeError("Manual input file required in MANUAL mode")

        run_blackbox_cli(
            "Manual_Execution_Original.py",
            [args.template_file, args.manual_input_file, output_file]
        )

        run_blackbox_cli(
            "test_execution_csv.py",
            [args.test_execution, args.test_plan, output_file]
        )

    else:
        run_blackbox_cli(
            "test_execution_csv_original_1.py",
            [
                args.template_file,
                args.test_execution,
                output_file,
                args.sw_component or ""
            ]
        )
    print("[TriWorX]  STAGE 1 csv Update  Executed ")
    
    try:
        run_blackbox_cli(
            "aadt_sims_enrichment.py",
            [
                output_file,
                args.test_execution
            ]
        
        )
    except Exception as e:
        print("[SIMS] Enrichment skipped due to error:", e)

    print("[TriWorX]  STAGE 1 SIMS enrichment Executed ")
    
    run_blackbox_cli(
        "triageTemplatePopulation_V6.py",
        [
            output_file,
            args.sw_version or "",
            args.rig_id or ""
        ]
    )
    print("[TriWorX]  STAGE 1 TemplatePopulation Executed ")
    
    print("[TriWorX]  STAGE 1 COMPLETED SUCCESSFULLY")
    print("[TriWorX] Output:", output_file)
    sys.exit(0)


# ============================================================
# GUI MODE (CREATED ONLY WHEN NEEDED)
# ============================================================

def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox

    def browse_file(entry):
        path = filedialog.askopenfilename()
        if path:
            entry.delete(0, tk.END)
            entry.insert(0, path)

    def generate_output_file():
        today = datetime.now().strftime("%d_%m_%Y")
        tp = test_plan_entry.get().strip()
        te = test_exec_keys_entry.get().split(",")[0].strip()
        return os.path.abspath(
            f"C:/JLR/Tools/Triage_python_script/"
            f"L0_Triage_Report_{today}_TP_{tp}_TE_{te}.xlsx"
        )

    def run_blackbox(script, args):
        sp = _script_path(script)
        result = subprocess.run([sys.executable, sp] + args)
        if result.returncode != 0:
            raise Exception(f"{script} failed")

    def run_pipeline():
        try:
            if not template_entry.get():
                raise ValueError("Triage Template File is mandatory")
            if not test_exec_keys_entry.get():
                raise ValueError("Test Execution Key is mandatory")
            if not test_plan_entry.get():
                raise ValueError("Test Plan ID is mandatory")

            output_file = generate_output_file()

            if execution_mode.get() == "MANUAL":
                run_blackbox(
                    "test_execution_csv.py",
                    [test_exec_keys_entry.get(), test_plan_entry.get(), output_file]
                )
            else:
                run_blackbox(
                    "test_execution_csv_original_1.py",
                    [
                        template_entry.get(),
                        test_exec_keys_entry.get(),
                        output_file,
                        sw_component_entry.get().strip()
                    ]
                )

            run_blackbox(
                "triageTemplatePopulation_V6.py",
                [
                    output_file,
                    sw_version_entry.get().strip(),
                    tams_entry.get().strip()
                ]
            )

            messagebox.showinfo("SUCCESS", f"Triage generated:\n\n{output_file}")

        except Exception as e:
            messagebox.showerror("Pipeline Failed", str(e))

    root = tk.Tk()
    root.title("L0 Triage Automation – Black‑Box GUI")
    root.geometry("950x480")

    frame = tk.Frame(root, padx=16, pady=16)
    frame.pack(fill=tk.BOTH, expand=True)

    def field(label, row, browse=False, required=False):
        tk.Label(frame, text=label + (" *" if required else "")).grid(
            row=row, column=0, sticky="w", pady=6
        )
        entry = tk.Entry(frame, width=72)
        entry.grid(row=row, column=1, padx=6)
        if browse:
            tk.Button(frame, text="Browse",
                      command=lambda e=entry: browse_file(e))\
                .grid(row=row, column=2)
        return entry

    row = 0
    template_entry = field("Triage Template File", row, browse=True, required=True); row += 1
    test_exec_keys_entry = field("Test Execution Keys", row, required=True); row += 1
    test_plan_entry = field("Test Plan ID", row, required=True); row += 1
    sw_version_entry = field("SW Version", row, required=True); row += 1
    tams_entry = field("TAMS ID", row, required=True); row += 1
    sw_component_entry = field("SW Component", row, required=True); row += 1

    execution_mode = tk.StringVar(value="AUTOMATED")

    tk.Button(
        frame,
        text="RUN TRIAGE",
        font=("Segoe UI", 11, "bold"),
        width=36,
        command=run_pipeline
    ).grid(row=row, column=1, pady=18)

    root.mainloop()


# ============================================================
# ENTRY POINT (THE FIX)
# ============================================================

if __name__ == "__main__":
    if "--template_file" in sys.argv:
        run_triworx_cli()
    else:
        run_gui()