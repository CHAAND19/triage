#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Extract results for a **single Test Execution** using the consolidated Xray endpoint:

Primary endpoint (Server/DC):
  GET /rest/raven/1.0/testruns?testExecKey=<EXEC-KEY>[&testKey=<TEST-KEY>][&limit=...&page=...]

This script:
- Inputs: Jira PAT token + Test Execution key
- Outputs: Excel + CSV with one row per Test Run in that execution
- Computes duration (minutes) from start/finish
- Adds resilient retry/backoff (429/5xx) and v1→v2 fallback
- Linkifies Jira-like keys in CSV and uses HYPERLINK() in Excel
"""
import sys
import json
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Any, Optional, Dict
import time
import re

import requests
import pandas as pd

# ===================== CONSTANTS =====================
BASE_URL = "https://jira.devops.jlr-apps.com"
JIRA_PAT = "MTI1NDQ4OTAzMjcwOtB3+hkVhMEJjt/kXxXnXXZioVtF"
ZSCALER_PEM = r"C:\\cert\\jira_allcert.pem"
PAGE_LIMIT = 100
# OUT_DIR = Path("output")

TEMPLATE_FILE = sys.argv[1]
TEST_EXEC_KEYS = sys.argv[2].split(",")   # required
# JIRA_PAT = sys.argv[3]  
OUTPUT_FILE = sys.argv[3]
SW_COMPONENT = sys.argv[4].strip()

print("Template :", TEMPLATE_FILE)

from shutil import copyfile
import os

# Validate template exists
if not os.path.exists(TEMPLATE_FILE):
    raise FileNotFoundError(f"Template not found: {TEMPLATE_FILE}")

# Ensure output file exists (copy template once)
if not os.path.exists(OUTPUT_FILE):
    print(
        "[FILE] Creating output workbook from template\n"
        f"  Template: {TEMPLATE_FILE}\n"
        f"  Output:   {OUTPUT_FILE}"
    )
    # ensure parent directory exists
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    copyfile(TEMPLATE_FILE, OUTPUT_FILE)

if not SW_COMPONENT:
    raise ValueError("SW Component not provided from GUI")

SW_COMPONENT = ",".join(
    c.strip() for c in SW_COMPONENT.split(",") if c.strip()
)

LOG_DIR = Path("logs")
# OUT_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

LOG_FILE = LOG_DIR / f"exec_extract_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

# ===================== LOGGING =====================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("jira-xray-exec-extract")

# ===================== JIRA LINKIFY HELPERS =====================
JIRA_BROWSE_BASE = f"{BASE_URL}/browse"
JIRA_KEY_RE = re.compile(r"\b[A-Z][A-Z0-9]+-\d+\b", re.IGNORECASE)


def _linkify_jira_ids_in_text(txt: str) -> str:
    if not isinstance(txt, str) or not txt:
        return txt

    def _to_url(m: re.Match) -> str:
        key = m.group(0).upper()
        return f"{JIRA_BROWSE_BASE}/{key}"

    return JIRA_KEY_RE.sub(_to_url, txt)


# [SUCCESS] Pandas‑2.2‑compatible linkify function
def _linkify_dataframe_for_csv(df: pd.DataFrame) -> pd.DataFrame:
    """
    Pandas 2.2 removed applymap(), so process string columns using Series.map().
    """
    df2 = df.copy()

    for col in df2.columns:
        if df2[col].dtype == "object":
            df2[col] = df2[col].map(
                lambda v: _linkify_jira_ids_in_text(v) if isinstance(v, str) else v
            )

    return df2


def _hyperlink_formula(issue_key: str) -> str:
    if isinstance(issue_key, str) and JIRA_KEY_RE.fullmatch(issue_key.strip()):
        key = issue_key.strip().upper()
        return f'=HYPERLINK("{JIRA_BROWSE_BASE}/{key}","{key}")'
    return issue_key


# ===================== SESSION =====================
def build_session(token: str) -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "User-Agent": "jira-xray-exec-extract/1.2",
    })
    return s


# ===================== AUTH =====================
def validate_jira_auth(session: requests.Session) -> None:
    url = f"{BASE_URL}/rest/api/2/myself"
    r = session.get(url)
    if r.status_code != 200:
        raise RuntimeError("Invalid Jira PAT token or missing permissions")
    logger.info("Authenticated as %s", r.json().get("displayName", "unknown"))


# ===================== DATE PARSER =====================
def _parse_iso8601_to_dt(s: Optional[str]) -> Optional[datetime]:
    if not s or not isinstance(s, str):
        return None
    txt = s.strip()
    if not txt:
        return None
    try:
        if txt.endswith("Z"):
            return datetime.fromisoformat(txt[:-1] + "+00:00").astimezone(timezone.utc)
        return datetime.fromisoformat(txt).astimezone(timezone.utc)
    except Exception:
        for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"):
            try:
                return datetime.strptime(txt, fmt).replace(tzinfo=timezone.utc)
            except Exception:
                pass
    return None

def format_datetime(dt_str):
    dt = _parse_iso8601_to_dt(dt_str)
    if not dt:
        return ""
    return dt.strftime("%d-%m-%Y %H:%M")


user_cache = {}

def get_display_name(username):
    if not username:
        return ""

    if username in user_cache:
        return user_cache[username]

    url = f"{BASE_URL}/rest/api/2/user?username={username}"
    r = requests.get(
        url,
        headers={"Authorization": f"Bearer {JIRA_PAT}", "Accept": "application/json"},
        verify=ZSCALER_PEM
    )

    if r.status_code == 200:
        display = r.json().get("displayName", username)
        user_cache[username] = display
        return display

    return username

def get_execution_evidences(session, exec_key):
    """
    Fetch attachment links from the Test Execution issue
    using the SAME session and retry logic.
    """
    url = f"{BASE_URL}/rest/api/2/issue/{exec_key}"
    params = {"fields": "attachment"}


    r = session.get(url, params=params, verify=ZSCALER_PEM)
    r.raise_for_status()

    attachments = r.json().get("fields", {}).get("attachment", [])

    return [
        att.get("content")
        for att in attachments
        if att.get("content")
    ]

def get_run_evidences(run):
    """
    Fetch run-level evidence (manual execution screenshots).
    Handles all Xray Server/DC variants.
    """

    evidences = run.get("evidences", [])
    if not isinstance(evidences, list):
        return []

    return [
        e.get("fileURL")
        for e in evidences
        if e.get("fileURL")
    ]

# ===================== RETRY WRAPPER =====================
def _get_with_retries(session, url, params=None, max_retries=5, base_sleep=1.0):
    attempt = 0
    while True:
        r = session.get(url, params=params)
        if r.status_code not in (429, 502, 503, 504):
            return r

        attempt += 1
        if attempt > max_retries:
            return r

        wait = None
        if r.status_code == 429:
            ra = r.headers.get("Retry-After")
            if ra:
                try:
                    wait = float(ra)
                except:
                    pass

        if wait is None:
            wait = base_sleep * (2 ** (attempt - 1))

        logger.warning("Retrying %s in %.1f seconds", url, wait)
        time.sleep(wait)


def _get_with_version_fallback(session, url_path, params=None):
    base = BASE_URL.rstrip('/')
    url = f"{base}{url_path}"

    r = _get_with_retries(session, url, params)
    if r.status_code == 404 and url_path.startswith("/rest/raven/1.0/"):
        alt = url_path.replace("/rest/raven/1.0/", "/rest/raven/2.0/", 1)
        alt_url = f"{base}{alt}"
        logger.info("Fallback → %s", alt_url)
        r = _get_with_retries(session, alt_url, params)
    return r


# ===================== XRAY RUN FETCH =====================
def fetch_runs_for_execution(session, exec_key: str, test_key: Optional[str] = None):
    page = 1
    results = []
    seen_ids = set()

    while True:
        params = {
            "testExecKey": exec_key,
            "limit": PAGE_LIMIT,
            "page": page   # [SUCCESS] use page
        }

        if test_key:
            params["testKey"] = test_key

        path = "/rest/raven/1.0/testruns"
        logger.info("[Xray] GET %s page=%d", path, page)

        r = _get_with_version_fallback(session, path, params)

        if r.status_code != 200:
            raise RuntimeError(f"Failed fetching testruns for {exec_key}")

        try:
            payload = r.json()
        except Exception:
            logger.info("No JSON response → stopping pagination")
            break


        # Normalize response
        if isinstance(payload, list):
            items = payload
        else:
            items = []
            for k in ("results", "values", "list", "testRuns", "data"):
                if isinstance(payload.get(k), list):
                    items = payload[k]
                    break

        if not items:
            break

        new_count = 0

        for item in items:
            run_id = item.get("id")

            if run_id not in seen_ids:
                seen_ids.add(run_id)
                results.append(item)
                new_count += 1

        logger.info("Fetched so far: %d", len(results))

        # [SUCCESS] CRITICAL FIX (prevents infinite + missing)
        if new_count == 0:
            logger.info("No new runs → stopping")
            break

        page += 1

        # [SUCCESS] safety guard
        if page > 50:
            logger.warning("Pagination safety limit hit → stopping")
            break

    logger.info("[SUCCESS] Total runs fetched: %d", len(results))
    return results


from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

def extract_for_execution(token, exec_key, only_test_key=None):
    session = build_session(token)
    validate_jira_auth(session)

    runs = fetch_runs_for_execution(session, exec_key, test_key=only_test_key)
    # ==========================================================
    # [SUCCESS] RECOVER MISSING RUNS (CRITICAL FIX)
    # ==========================================================

    # Collect keys from fetched runs
    run_keys = set()
    for r in runs:
        tk = r.get("testKey") or (r.get("test") or {}).get("key")
        if tk:
            run_keys.add(tk.strip())

    # Fetch ground truth list of tests
    jql = f'issue in testExecutionTests("{exec_key}")'
    resp = session.get(
        f"{BASE_URL}/rest/api/2/search",
        params={"jql": jql, "fields": "key", "maxResults": 1000},
        verify=ZSCALER_PEM
    )

    test_keys = set([i["key"] for i in resp.json().get("issues", [])])

    # Find missing
    missing_keys = test_keys - run_keys

    if missing_keys:
        logger.warning(f" Missing runs detected: {len(missing_keys)}")

        for tk in missing_keys:
            params = {
                "testExecKey": exec_key,
                "testKey": tk
            }

            r = session.get(
                f"{BASE_URL}/rest/raven/1.0/testruns",
                params=params,
                verify=ZSCALER_PEM
            )

            if r.status_code == 200:
                payload = r.json()

                if isinstance(payload, list):
                    if payload:
                        runs.append(payload[0])
                        logger.info(f"Recovered: {tk}")

    # ==========================================================

    if not runs:
        raise RuntimeError("No runs found for this Test Execution.")

    # [SUCCESS] DEFINE execution_evidences HERE
    execution_evidences = get_execution_evidences(session, exec_key)

    print(f"EXECUTION EVIDENCES FETCHED FOR {exec_key}: {execution_evidences}")
   
    write_runs_to_template(
        OUTPUT_FILE,
        exec_key,
        runs,
        execution_evidences
    )

    logger.info(
        "Written %d test runs to template for %s",
        len(runs),
        exec_key
    )


def write_runs_to_template(OUTPUT_FILE, exec_key, runs, execution_evidences):
    wb = load_workbook(OUTPUT_FILE)

    if exec_key in wb.sheetnames:
        del wb[exec_key]

    ws = wb.create_sheet(exec_key)
    
     # ============================================================
    # [SUCCESS] SAFE DEDUPLICATION – NO TEST CASE LOSS
    # ============================================================

    df = pd.DataFrame(runs)

    # ---- 1. Resolve testKey safely (critical)
    def resolve_test_key(row):
        if pd.notna(row.get("testKey")):
            return str(row["testKey"]).strip()
        if isinstance(row.get("test"), dict) and row["test"].get("key"):
            return str(row["test"]["key"]).strip()
        return None

    df["ResolvedTestKey"] = df.apply(resolve_test_key, axis=1)

    # ---- 2. FAIL FAST if any testKey could not be resolved
    missing = df[df["ResolvedTestKey"].isna()]
    if not missing.empty:
        raise Exception(
            f"[ERROR] {len(missing)} runs missing testKey — cannot safely deduplicate"
        )

    # ---- 3. Resolve start time safely
    if "start" in df.columns:
        dt_src = df["start"]
    elif "startDate" in df.columns:
        dt_src = df["startDate"]
    else:
        dt_src = pd.Series([None] * len(df))

    df["Start_dt"] = pd.to_datetime(dt_src, errors="coerce")
    df["Start_dt"] = df["Start_dt"].fillna(pd.Timestamp.min)

    # ---- 4. Sort latest run first
    df = df.sort_values("Start_dt", ascending=False)

    # ---- 5. Deduplicate by resolved key
    df = df.drop_duplicates(subset=["ResolvedTestKey"], keep="first")

    # ---- 6. Replace runs safely
    runs = df.drop(columns=["ResolvedTestKey", "Start_dt"]).to_dict(orient="records")

    # # REMOVE template Excel table (THIS IS THE FIX)
    # if ws._tables:
    #     ws._tables.clear()


    headers = [
        "Test Execution Key",
        "Test Key",
        "SW Component",
        "Executed By",
        "Assignee",
        "Start",
        "Finish",
        "Defects",
        "Evidences",
        "Comment",
        "Status",
    ]
    ws.append(headers)

    for run in runs:

        test_key = (run.get("testKey") or "").strip()

        # sw_component = (run.get("swComponent") or run.get("component") or "")
        # # Normalize formatting
        # if isinstance(sw_component, str):
        #     sw_component = ",".join(
        #         [c.strip() for c in sw_component.split(",") if c.strip()]
        #     )
        # else:
        #     sw_component = ""

        executed_by = get_display_name(run.get("executedBy", ""))
        # assignee = get_display_name(run.get("assignee", ""))
        
        assignee_user = (
            run.get("assignee")        # rarely present in test run
            or run.get("executedBy")   # reliable in automation
            or ""
        )

        assignee = get_display_name(assignee_user)

        raw_start = run.get("start") or run.get("startDate", "")
        raw_finish = run.get("finish") or run.get("finishedOn", "")
        start = format_datetime(raw_start)
        finish = format_datetime(raw_finish)

        raw_defects = run.get("defects", "")
        if isinstance(raw_defects, list):
            defects = ",".join(d.get("key", "") for d in raw_defects if isinstance(d, dict))
        else:
            defects = raw_defects or ""

        # [SUCCESS] Evidence handling — prefer HTML test report
        run_evidences = get_run_evidences(run)

        if run_evidences:
            # Prefer HTML report
            html_links = [u for u in run_evidences if u.lower().endswith(".html")]

            if html_links:
                final_evidences = [html_links[0]]
            else:
                final_evidences = [run_evidences[0]]
        else:
            # Fallback to execution-level evidence
            html_links = [u for u in execution_evidences if u.lower().endswith(".html")]

            if html_links:
                final_evidences = [html_links[0]]
            elif execution_evidences:
                final_evidences = [execution_evidences[0]]
            else:
                final_evidences = []     # automated

        comment = run.get("comment", "")
        status = run.get("status")
        if isinstance(status, dict):
            status = status.get("name") or status.get("status")
        status = status or ""

        ws.append([
            exec_key,
            test_key,
            SW_COMPONENT,
            executed_by,
            assignee,
            start,
            finish,
            defects,
            "\n".join(final_evidences),   # [SUCCESS] evidences written correctly
            comment,
            status,
        ])

    # Clear filters
    ws.auto_filter.ref = None
    ws.auto_filter.ref = f"A1:K{ws.max_row}"

    # [SUCCESS] Force Excel to open this sheet
    wb.active = wb.index(ws)

    wb.save(OUTPUT_FILE)

    for col in ws.columns:
        max_len = max((len(str(c.value)) for c in col if c.value), default=10)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max_len + 2, 80)

    wb.save(OUTPUT_FILE)

# ===================== WORKFLOW =====================
def extract_for_execution(token, exec_key, only_test_key=None):
    session = build_session(token)
    validate_jira_auth(session)

    runs = fetch_runs_for_execution(session, exec_key, test_key=only_test_key)
    if not runs:
        raise RuntimeError("No runs found for this Test Execution.")

    # ==========================================================
    # [SUCCESS] FIND MISSING TESTS (FINAL DIAGNOSTIC)
    # ==========================================================

    # ---- 1. Collect run keys
    run_keys = set()
    for r in runs:
        tk = r.get("testKey") or (r.get("test") or {}).get("key")
        if tk:
            run_keys.add(tk.strip())

    # ---- 2. Fetch all expected test keys (ground truth)
    jql = f'issue in testExecutionTests("{exec_key}")'

    resp = session.get(
        f"{BASE_URL}/rest/api/2/search",
        params={
            "jql": jql,
            "fields": "key",
            "maxResults": 1000
        },
        verify=ZSCALER_PEM
    )

    if resp.status_code != 200:
        raise RuntimeError("Failed to fetch testExecutionTests JQL")

    issues = resp.json().get("issues", [])
    test_keys = set(issue["key"].strip() for issue in issues)

    # ---- 3. Compare
    missing_keys = test_keys - run_keys

    print("\n================ MISSING TESTS ANALYSIS ================")
    print("Total tests (JQL):", len(test_keys))
    print("Total runs fetched:", len(run_keys))

    print("\n Missing Test Runs (executed but NOT returned by API):")
    for k in sorted(missing_keys):
        print("   ", k)

    print("=========================================================\n")

    # ==========================================================
    # [SUCCESS] RECOVER & ADD MISSING TEST RUNS
    # ==========================================================

    if missing_keys:
        logger.warning(f" Recovering {len(missing_keys)} missing runs")

        for tk in missing_keys:
            params = {
                "testExecKey": exec_key,
                "testKey": tk
            }

            r = session.get(
                f"{BASE_URL}/rest/raven/1.0/testruns",
                params=params,
                verify=ZSCALER_PEM
            )

            if r.status_code != 200:
                logger.warning(f"[ERROR] Failed to recover {tk}")
                continue

            try:
                payload = r.json()
            except Exception:
                logger.warning(f"[ERROR] Invalid JSON for {tk}")
                continue

            # Normalize response
            if isinstance(payload, list):
                items = payload
            else:
                items = []
                for k in ("results", "values", "testRuns", "data"):
                    if isinstance(payload.get(k), list):
                        items = payload[k]
                        break

            if items:
                runs.append(items[0])   # [SUCCESS] add recovered run
                logger.info(f"[SUCCESS] Recovered: {tk}")
            else:
                logger.warning(f"[WARN] No run data for {tk}")

    # ==========================================================

    # [SUCCESS] DEFINE execution-level evidence ONCE
    execution_evidences = get_execution_evidences(session, exec_key)
    
    print(f"EXECUTION EVIDENCES FETCHED FOR {exec_key}: {execution_evidences}")

    # WRITE META FILE (THIS IS THE MISSING STEP)
    import json
    import os

    meta_path = OUTPUT_FILE.replace(".xlsx", "_meta.json")

    with open(meta_path, "w") as f:
        json.dump({
            "evidence_links": execution_evidences
        }, f)

    print(f"[TriWorX] Meta written: {meta_path}")

    write_runs_to_template(OUTPUT_FILE, exec_key, runs, execution_evidences)
    logger.info("Written %d test runs to template for %s", len(runs), exec_key)

if __name__ == "__main__":
    # token = sys.argv[4]

    token = "MTI1NDQ4OTAzMjcwOtB3+hkVhMEJjt/kXxXnXXZioVtF"
    for exec_key in TEST_EXEC_KEYS:
        extract_for_execution(token, exec_key)