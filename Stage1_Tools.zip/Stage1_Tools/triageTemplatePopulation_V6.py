import sys
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
import re
from datetime import datetime, date


# =====================================================================
#  USER CONFIG
# =====================================================================
# FILE = "L0_Triage_Report_03_04_2026_TP_AADT-245707_TE_AADT-268012.xlsx"
FILE = sys.argv[1]
SW_VERSION_GUI = sys.argv[2]
TAMS_ID_GUI = sys.argv[3]

print("DEBUG: FILE used for load/save =", FILE)

print("INPUT FILE:", FILE)


AUTO_PREFIX = "AADT-"
MANUAL_PREFIX = "Manual_Extract_AADT-"
PLACEHOLDER_PREFIX = "XX_XX_XX_Drop"

TAMS_VALUE = "TAMS-6721"
JIRA_BASE = "https://jira.devops.jlr-apps.com/browse/"


# =====================================================================
#  LOAD WORKBOOK & DETECT SHEETS
# =====================================================================

wb = load_workbook(FILE)
sheets = wb.sheetnames

AUTO_PREFIX = "AADT-"
MANUAL_PREFIX = "Manual_Extract_AADT-"

#  Detect automation execution sheets
aadts = [s for s in sheets if s.startswith(AUTO_PREFIX)]
if not aadts:
    raise Exception(" No AADT execution sheet found")

AADT_SHEET = aadts[-1]
print(" Using AADT sheet:", AADT_SHEET)

#  Detect manual extract sheets
manual_sheets = [s for s in sheets if s.startswith(MANUAL_PREFIX)]


#  DEFINE MODE (THIS WAS MISSING)
AUTOMATION_MODE = len(manual_sheets) == 0
print(" Mode:", "AUTOMATION" if AUTOMATION_MODE else "MANUAL")

# =====================================================================
#  LOAD MANUAL DATA ONLY IF IN MANUAL MODE
# =====================================================================
manual = None

if not AUTOMATION_MODE:
    manual_sheet = manual_sheets[0]

    manual = pd.read_excel(
        FILE,
        sheet_name=manual_sheet,
        engine="openpyxl",
        dtype=str
    ).fillna("")

    manual.columns = manual.columns.str.strip()

    #  Extract TestID ONLY in manual mode
    manual["TestID"] = manual["TestID"].str.extract(r"(AADT-\d+)")


# =====================================================================
#  LOAD AUTOMATION DATA (ALWAYS)
# =====================================================================
auto = pd.read_excel(
    FILE,
    sheet_name=AADT_SHEET,
    engine="openpyxl",
    dtype=str
).fillna("")

auto.columns = auto.columns.str.strip()

# manual["TestID"] = manual["TestID"].str.extract(r"(AADT-\d+)")
auto["Test Key"] = auto["Test Key"].str.extract(r"(AADT-\d+)")

# ============================================================
#  SW COMPONENT RESOLUTION (MODE‑AWARE)
# ============================================================
if AUTOMATION_MODE:
    if "SW Component" not in auto.columns:
        raise Exception(" SW Component column missing in AADT sheet")

    SW_COMPONENT = (
        auto["SW Component"]
        .dropna()
        .astype(str)
        .str.strip()
        .iloc[0]
    )
else:
    # Manual mode: value will be taken per row
    SW_COMPONENT = None

print(" Using SW Component:", SW_COMPONENT)

# ============================================================
#  SW VERSION (MODE‑AWARE)
# ============================================================
if AUTOMATION_MODE:
    sw_version = SW_VERSION_GUI
else:
    if "SW Version" not in manual.columns:
        raise Exception(" 'SW Version' column missing in manual sheet")

    sw_version = manual["SW Version"].iloc[0]

print("  Using SW Version:", sw_version)



# =====================================================================
#  FETCH Test Execution ID from AADT sheet DATA (authoritative)
# =====================================================================
if "Test Execution Key" not in auto.columns:
    raise Exception(" 'Test Execution Key' column not found in AADT sheet")

TEST_EXECUTION_ID = (
    auto["Test Execution Key"]
    .dropna()
    .astype(str)
    .str.strip()
    .iloc[0]
)

print(" Using Test Execution ID:", TEST_EXECUTION_ID)

# =====================================================================
#  AUTO-DETECT EVIDENCE COLUMN
# =====================================================================
evidence_candidates = [
    col for col in auto.columns
    if "eviden" in col.lower() or "attach" in col.lower() or "jira" in col.lower()
]

if not evidence_candidates:
    raise Exception(" Evidence column not found!")

EVIDENCE_COL = evidence_candidates[0]


# =====================================================================
#  AUTO-DETECT SIMS COLUMN
# =====================================================================
sims_candidates = [
    col for col in auto.columns
    if "defect" in col.lower() or "issue" in col.lower() or "sims" in col.lower()
]

SIMS_COL = sims_candidates[0] if sims_candidates else None

#print("DEBUG COL_EXEC_ID =", COL_EXEC_ID, type(COL_EXEC_ID))
#print("DEBUG COL_TESTCASE =", COL_TESTCASE, type(COL_TESTCASE))
#print("DEBUG COL_SIMSLINK =", COL_SIMSLINK, type(COL_SIMSLINK))
# =====================================================================
#  BUILD FINAL SHEET NAME
# =====================================================================
if AUTOMATION_MODE:
    sw_version = SW_VERSION_GUI
    TAMS_VALUE = TAMS_ID_GUI
else:
    sw_version = manual["SW Version"].iloc[0]

    if "TAMS ID" in manual.columns:
        TAMS_VALUE = str(manual["TAMS ID"].iloc[0]).strip()
    elif "TAMS_ID" in manual.columns:
        TAMS_VALUE = str(manual["TAMS_ID"].iloc[0]).strip()
    else:
        raise Exception(" 'TAMS ID' or 'TAMS_ID' column not found in manual sheet")


# =====================================================================
#  BUILD FINAL SHEET NAME (USE RESOLVED VALUES)
# =====================================================================
DROP_NAME = re.search(r"Drop(\d+\.\d+)", sw_version).group(1)
SW_DATE = re.search(r"(\d{2}\.\d{2}\.\d{2})", sw_version).group(1)
TODAY = datetime.now().strftime("%d-%m-%y")

FINAL_SHEET_NAME = f"{TODAY}_Drop{DROP_NAME}_M_{SW_DATE}"


# =====================================================================
#  SELECT TEMPLATE / FINAL SHEET (BACKWARD + FORWARD COMPATIBLE)
# =====================================================================

# 1️⃣ Placeholder sheet (initial template)
placeholder_sheet = next(
    (s for s in sheets if s.startswith(PLACEHOLDER_PREFIX)),
    None
)

# 2️⃣ Existing final sheet
#    Supports:
#    - Old format: 21-04-24_DropX_Y
#    - New format: AADT-273833_21-04-2024
existing_final = next(
    (
        s for s in sheets
        if re.match(r"^\d{2}-\d{2}-\d{2}", s)   # old numeric date format
        or re.match(r"^AADT-\d+_", s)           # new AADT_<date> format
    ),
    None
)

if existing_final:
    ws = wb[existing_final]
    FINAL_SHEET_NAME = existing_final

elif placeholder_sheet:
    ws = wb[placeholder_sheet]
    ws.title = FINAL_SHEET_NAME

else:
    raise Exception(
        " No placeholder or existing final sheet found in workbook"
    )

print("  Using final sheet:", ws.title)

# =====================================================================
#  CLEAR EXCEL TABLE ROWS (MANDATORY when reusing same sheet)
# =====================================================================
#  CLEAR TABLE DATA BUT KEEP HEADER ROW (correct & reliable)
if ws._tables:
    for tbl in ws._tables.values():
        start, end = tbl.ref.split(":")
        start_col = re.sub(r"\d+", "", start)
        end_col = re.sub(r"\d+", "", end)
        tbl.ref = f"{start_col}1:{end_col}1"

# =====================================================================
#  BACKUP COMMENTS FROM HEADER ROWS (THIS IS THE FIX!)
# =====================================================================
header_comments = {}

HEADER_ROWS = [1, 2, 3]   # supports merged heads + multilayer headers

for row in HEADER_ROWS:
    for col in ws.iter_cols(1, ws.max_column):
        cell = col[row - 1]
        if cell.comment:                       # now works because comments = Notes
            header_comments[cell.coordinate] = cell.comment


# =====================================================================
#  SAFE COLUMN DETECTOR — DOES NOT TOUCH HEADER CELLS
# =====================================================================
def find_col(patterns, header_rows=(1, 2, 3)):
    for col_cells in ws.iter_cols(1, ws.max_column):
        for row_idx in header_rows:
            cell = col_cells[row_idx - 1]
            if not cell.value:
                continue

            header = str(cell.value).lower()
            header = header.replace("_", " ")
            header = re.sub(r"[()?:]", "", header)
            header = re.sub(r"\s+", " ", header).strip()

            for p in patterns:
                if p in header:
                    return col_cells[0].column_letter  #  FIX
    return None


# =====================================================================
#  DETECT TEMPLATE COLUMN LETTERS
# =====================================================================
COL_EXEC_ID   = find_col(["execution"])
COL_TESTCASE  = find_col(["test case"])
COL_TAMS      = find_col(["tams"])
COL_SWCOMP    = find_col(["sw comp"])
COL_VERDICT   = find_col(["verdict"])
COL_DATE      = find_col(["date"])
COL_REASON    = find_col(["failure"])
COL_SWVERSION = find_col(["sw version"])
COL_TESTER    = find_col(["tester"])
COL_EVID      = find_col(["evidence"])
COL_SIMSLINK  = find_col(["sims", "linked"])

required = [
    COL_EXEC_ID, COL_TESTCASE, COL_TAMS, COL_SWCOMP,
    COL_VERDICT, COL_DATE, COL_REASON, COL_SWVERSION,
    COL_TESTER, COL_EVID, COL_SIMSLINK
]

if None in required:
    raise Exception(" Template headers missing or renamed!")


# =====================================================================
#  MERGE DATA
# =====================================================================
# merge_cols = ["Test Key", EVIDENCE_COL]
# if SIMS_COL:
#     merge_cols.append(SIMS_COL)

# merged = manual.merge(
#     auto[merge_cols],
#     left_on="TestID",
#     right_on="Test Key",
#     how="left"
# )

# =====================================================================
#  BUILD FINAL INPUT DATA (Automation vs Manual)
# =====================================================================
if AUTOMATION_MODE:
    print("  Building data from automation only")

    final_df = auto.copy()
    final_df["TestID"] = final_df["Test Key"]

else:
    print("  Building data from manual + automation")

    manual_sheet = manual_sheets[0]
    manual = pd.read_excel(FILE, sheet_name=manual_sheet, engine="openpyxl", dtype=str).fillna("")
    manual.columns = manual.columns.str.strip()

    manual["TestID"] = manual["TestID"].str.extract(r"(AADT-\d+)")
    auto["Test Key"] = auto["Test Key"].str.extract(r"(AADT-\d+)")

    merge_cols = ["Test Key"]
    if "Evidences" in auto.columns:
        merge_cols.append("Evidences")
    if "Defects" in auto.columns:
        merge_cols.append("Defects")

    final_df = manual.merge(
        auto[merge_cols],
        left_on="TestID",
        right_on="Test Key",
        how="left"
    )

# =====================================================================
#  CLEAR ALL DATA ROWS (keep headers only)
# =====================================================================
# if ws.max_row > 1:
#     ws.delete_rows(2, ws.max_row - 1)
start_row = 2


# =====================================================================
#  COMMENT-PRESERVING WRITER
# =====================================================================
def write_with_comment(cell, value):
    # Unwrap range tuples like ws["A2:B2"] -> take first Cell
    while isinstance(cell, (tuple, list)):
        cell = cell[0]

    saved = getattr(cell, "comment", None)
    cell.value = value
    if saved is not None:
        cell.comment = saved

    return cell  #  return the real Cell object

# =====================================================================
#  POPULATE ROWS
# =====================================================================
# TEST_EXECUTION_ID = auto_sheet

for idx, rec in final_df.iterrows():

    r = start_row + idx

    write_with_comment(ws[f"{COL_EXEC_ID}{r}"], TEST_EXECUTION_ID)
    write_with_comment(ws[f"{COL_TESTCASE}{r}"], rec["TestID"])
    write_with_comment(ws[f"{COL_TAMS}{r}"], TAMS_VALUE)
    if AUTOMATION_MODE:
        write_with_comment(ws[f"{COL_SWCOMP}{r}"], SW_COMPONENT)
    else:
        write_with_comment(ws[f"{COL_SWCOMP}{r}"], rec["SW_Component"])
    # ============================================================
    #  VERDICT RESOLUTION (MODE‑AWARE)
    # ============================================================
    
    if AUTOMATION_MODE:
        verdict = (
            rec.get("Status")
            or rec.get("Run Verdict")
            or ""
        )
    else:
        verdict = rec.get("Verdict", "")

    write_with_comment(ws[f"{COL_VERDICT}{r}"], verdict)

    
    # --------------------------------------------------------
    # DATE OF EXECUTION (MODE‑AWARE, DD‑MM‑YYYY)
    # --------------------------------------------------------
   
    exec_date = ""

    if AUTOMATION_MODE:
        raw_date = rec.get("Start", "")
    else:
        raw_date = rec.get("Date of execution", "")

    if raw_date:
        try:
            # Example: 19-04-2026 12:50 → 19-04-2026
            date_part = raw_date.split(" ")[0]

            # Try DD-MM-YYYY first (your automation case)
            try:
                d = datetime.strptime(date_part, "%d-%m-%Y").date()
            except ValueError:
                # Fallback: ISO YYYY-MM-DD
                d = datetime.fromisoformat(date_part).date()

            exec_date = d
        except Exception:
            exec_date = ""

    cell = write_with_comment(ws[f"{COL_DATE}{r}"], exec_date)
    cell.number_format = "DD-MM-YYYY"


    # ============================================================
    #  FAILURE REASON (MODE-AWARE)
    # ============================================================
    if AUTOMATION_MODE:
        failure_reason = ""   # No manual failure reason in automation
    else:
        failure_reason = rec.get("Failure Reason (Test Automation Team)", "")
    
    write_with_comment(ws[f"{COL_REASON}{r}"], failure_reason)

    write_with_comment(ws[f"{COL_SWVERSION}{r}"], sw_version)
    # ============================================================
    #  ASSIGNEE RESOLUTION (MODE‑AWARE)
    # ============================================================
    if AUTOMATION_MODE:
        # Xray does not give assignee at run level → fallback to executor
        assignee_user = rec.get("Executed By", "") or rec.get("executedBy", "")
    else:
        assignee_user = rec.get("Assignee", "")

    assignee = assignee_user
    write_with_comment(ws[f"{COL_TESTER}{r}"], assignee)

    #  Evidence Links
    #  Evidence Links (FIXED)
    #  Evidence Links (NaN-safe FIX)
    evid = rec.get(EVIDENCE_COL, "")
    cell = ws[f"{COL_EVID}{r}"]

    if pd.notna(evid) and str(evid).strip():
        urls = [u.strip() for u in str(evid).split(",") if u.strip()]

        write_with_comment(cell, "\n".join(urls))
        cell.alignment = Alignment(wrap_text=True)

        # Optional: first evidence clickable
        cell.hyperlink = urls[0]
        cell.font = Font(color="0000EE", underline="single")
    else:
        write_with_comment(cell, "NA")
        evid = rec.get(EVIDENCE_COL)
        cell = ws[f"{COL_EVID}{r}"]
        if pd.notna(evid) and str(evid).strip():
            urls = [u.strip() for u in str(evid).split(",") if u.strip()]

            cell = write_with_comment(cell, "\n".join(urls))  #  use returned cell
            cell.alignment = Alignment(wrap_text=True)

            cell.hyperlink = urls[0]
            cell.font = Font(color="0000EE", underline="single")
        else:
            cell = write_with_comment(cell, "NA")  #  consistent

    #  SIMS
    sims = rec.get("Defects", "") or (rec.get(SIMS_COL, "") if SIMS_COL else "")
    sims = sims if (sims and str(sims).strip()) else "NA"
    write_with_comment(ws[f"{COL_SIMSLINK}{r}"], sims)


# =====================================================================
#  RESTORE HEADER COMMENTS EXACTLY
# =====================================================================
for coord, comment in header_comments.items():
    ws[coord].comment = comment   # now works because these are Notes


# =====================================================================
#  APPLY JIRA HYPERLINKS
# =====================================================================
for idx in range(len(final_df)):
    r = start_row + idx

    case_id = ws[f"{COL_TESTCASE}{r}"].value
    exec_id = ws[f"{COL_EXEC_ID}{r}"].value

    if case_id and case_id != "NA":
        ws[f"{COL_TESTCASE}{r}"].hyperlink = f"{JIRA_BASE}{case_id}"
        ws[f"{COL_TESTCASE}{r}"].font = Font(color="0000EE", underline="single")

    if exec_id:
        ws[f"{COL_EXEC_ID}{r}"].hyperlink = f"{JIRA_BASE}{exec_id}"
        ws[f"{COL_EXEC_ID}{r}"].font = Font(color="0000EE", underline="single")


# =====================================================================
#  COLOR VERDICT
# =====================================================================
for idx in range(len(final_df)):
    r = start_row + idx
    verdict = (ws[f"{COL_VERDICT}{r}"].value or "").upper()

    if verdict == "PASS":
        ws[f"{COL_VERDICT}{r}"].fill = PatternFill(
            start_color="C6EFCE", fill_type="solid"  # Light Green
        )

    elif verdict == "FAIL":
        ws[f"{COL_VERDICT}{r}"].fill = PatternFill(
            start_color="FFC7CE", fill_type="solid"  # Light Red
        )

    elif verdict == "TODO":
        ws[f"{COL_VERDICT}{r}"].fill = PatternFill(
            start_color="D9D9D9", fill_type="solid"  # Light Gray
        )

    else:
        # Optional: clear color if unknown
        ws[f"{COL_VERDICT}{r}"].fill = PatternFill(fill_type=None)
# =====================================================================
#  EXTEND TABLE TO INCLUDE NEWLY WRITTEN DATA (MANDATORY)
# =====================================================================
if ws._tables:
    for tbl in ws._tables.values():
        start, end = tbl.ref.split(":")
        start_col = re.sub(r"\d+", "", start)
        end_col = re.sub(r"\d+", "", end)
        tbl.ref = f"{start_col}1:{end_col}{ws.max_row}"


# =====================================================================
#  SAVE WITHOUT LOSING COMMENTS
# =====================================================================
wb.save(FILE)
print(f" SUCCESS — {len(final_df)} rows added at row {start_row} in '{FINAL_SHEET_NAME}'. Comments preserved.")