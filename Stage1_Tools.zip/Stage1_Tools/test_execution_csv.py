import requests
import sys
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from datetime import datetime

# ----------------------------------------------
# CONFIGURATION
# ----------------------------------------------
BASE_URL = "https://jira.devops.jlr-apps.com"
JIRA_PAT = "MTI1NDQ4OTAzMjcwOtB3+hkVhMEJjt/kXxXnXXZioVtF"
ZSCALER_PEM = r"C:\\cert\\jira_allcert.pem"


TEST_EXEC_KEYS = sys.argv[1].split(",")
TEST_PLAN = sys.argv[2]
OUTPUT_FILE = sys.argv[3]


# PAGE_LIMIT = 100

# ----------------------------------------------
# USER FULL NAME LOOKUP (cached)
# ----------------------------------------------
user_cache = {}

def get_display_name(username):
    if not username:
        return ""

    if username in user_cache:
        return user_cache[username]

    url = f"{BASE_URL}/rest/api/2/user?username={username}"
    r = requests.get(
        url,
        headers={"Authorization": f"Bearer {JIRA_PAT}", "Accept": "application/json"},
        verify=ZSCALER_PEM
    )

    if r.status_code == 200:
        display = r.json().get("displayName", username)
        user_cache[username] = display
        return display

    return username


# ----------------------------------------------
# LOAD TEMPLATE WORKBOOK
# ----------------------------------------------
wb = load_workbook(OUTPUT_FILE)
print(f"Loaded template: {OUTPUT_FILE}")


# ----------------------------------------------
# PROCESS EACH TEST EXECUTION (MANUAL)
# ----------------------------------------------
for te_key in TEST_EXEC_KEYS:

    print(f"Fetching Test Execution  : {te_key}")

    api_url = f"{BASE_URL}/rest/raven/1.0/api/testexec/{te_key}/test?detailed=true"

    response = requests.get(
        api_url,
        headers={"Authorization": f"Bearer {JIRA_PAT}", "Accept": "application/json"},
        verify=ZSCALER_PEM
    )

    # JSON safe decode
    try:
        data = response.json()
    except ValueError:
        print("ERROR: Response is not JSON. Raw output:")
        print("Status:", response.status_code)
        print(response.text)
        continue  # skip this execution safely

    # Create sheet in template workbook
    ws = wb.create_sheet(title=te_key)

    headers = [
        "Test Execution Key",
        "Test Key",
        "Executed By",
        "Assignee",
        "Start",
        "Finish",
        "Defects",
        "Evidences",
        "Comment",
        "Status"
    ]

    ws.append(headers)

    # Fill rows
    for entry in data:

        test_key = (
            entry.get("testKey")
            or entry.get("key")
            or (entry.get("test", {}) or {}).get("key")
            or ""
        )

        executed_by = get_display_name(entry.get("executedBy", ""))
        assignee = get_display_name(entry.get("assignee", ""))

        defects = ",".join(d.get("key", "") for d in entry.get("defects", []))
        evidences = ",".join(e.get("fileURL", "") for e in entry.get("evidences", []))

        ws.append([
            te_key,
            test_key,
            executed_by,
            assignee,
            entry.get("start", ""),
            entry.get("finish", ""),
            defects,
            evidences,
            entry.get("comment", ""),
            entry.get("status", "")
        ])

    # Add filter
    ws.auto_filter.ref = f"A1:I{ws.max_row}"

    # Auto-fit column widths
    for col in ws.columns:
        max_len = 0
        col_lett = get_column_letter(col[0].column)
        for cell in col:
            if cell.value:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_lett].width = max_len + 2

    print(f" Manual sheet created : {te_key}")


# ----------------------------------------------
# SAVE FINAL WORKBOOK
# ----------------------------------------------
wb.save(OUTPUT_FILE)
print(f" ALL DONE : {OUTPUT_FILE}")