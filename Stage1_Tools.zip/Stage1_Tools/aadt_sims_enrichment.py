#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import requests
from openpyxl import load_workbook
from concurrent.futures import ThreadPoolExecutor

# -------------------------------------------------
# CONFIGURATION
# -------------------------------------------------
BASE_URL = "https://jira.devops.jlr-apps.com"
ZSCALER_PEM = r"C:\\cert\\jira_allcert.pem"
JIRA_PAT = "MTI1NDQ4OTAzMjcwOtB3+hkVhMEJjt/kXxXnXXZioVtF"

EXCEL_FILE = sys.argv[1]
TEST_EXEC_KEY = sys.argv[2]
# JIRA_PAT = sys.argv[3]

# -------------------------------------------------
# SESSION (REUSE CONNECTION [SUCCESS])
# -------------------------------------------------
session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {JIRA_PAT}",
    "Accept": "application/json"
})

# -------------------------------------------------
# CACHE (AVOID REPEATED CALLS [SUCCESS])
# -------------------------------------------------
sims_cache = {}


# -------------------------------------------------
# FETCH SIMS
# -------------------------------------------------
def fetch_sims_for_test(test_key):
    if test_key in sims_cache:
        return sims_cache[test_key]

    url = f"{BASE_URL}/rest/api/2/issue/{test_key}"
    params = {"fields": "issuelinks"}

    resp = session.get(url, params=params, verify=ZSCALER_PEM)

    if resp.status_code != 200:
        print(f"[ERROR] Failed: {test_key}")
        sims_cache[test_key] = ""
        return ""

    data = resp.json()
    links = data.get("fields", {}).get("issuelinks", [])

    sims = []

    for link in links:
        linked = link.get("outwardIssue") or link.get("inwardIssue")

        if not linked:
            continue

        key = linked.get("key", "").upper()
        status = linked.get("fields", {}).get("status", {}).get("name", "")

        if key.startswith("SIMS-") and status != "Completed":
            sims.append(key)

    result = ",".join(sorted(set(sims)))
    sims_cache[test_key] = result

    return result


# -------------------------------------------------
# PROCESS ROW (FOR THREADING [SUCCESS])
# -------------------------------------------------
def process_row(args):
    row, ws, TEST_KEY_COL, DEFECT_COL = args

    test_key = (ws.cell(row, TEST_KEY_COL).value or "").strip().upper()
    defects = (ws.cell(row, DEFECT_COL).value or "").strip()

    if not test_key or defects:
        return None

    sims = fetch_sims_for_test(test_key)

    if sims:
        return (row, sims)

    return None


# -------------------------------------------------
# MAIN
# -------------------------------------------------
print(f"\n[INFO] Loading Excel file: {EXCEL_FILE}")

wb = load_workbook(EXCEL_FILE)

if TEST_EXEC_KEY not in wb.sheetnames:
    raise Exception(f"[ERROR] Sheet not found: {TEST_EXEC_KEY}")

ws = wb[TEST_EXEC_KEY]

# Identify columns
headers = {cell.value: idx + 1 for idx, cell in enumerate(ws[1])}
TEST_KEY_COL = headers.get("Test Key")
DEFECT_COL = headers.get("Defects")

if not TEST_KEY_COL or not DEFECT_COL:
    raise Exception("[ERROR] Required columns missing")

print(f"[SUCCESS] Processing {ws.max_row - 1} tests...\n")

# -------------------------------------------------
# [SUCCESS] PARALLEL PROCESSING
# -------------------------------------------------
tasks = [
    (row, ws, TEST_KEY_COL, DEFECT_COL)
    for row in range(2, ws.max_row + 1)
]

results = []

with ThreadPoolExecutor(max_workers=10) as executor:
    results = list(executor.map(process_row, tasks))

# -------------------------------------------------
# [SUCCESS] UPDATE EXCEL (ONCE → FAST)
# -------------------------------------------------
updated = 0

for res in results:
    if res:
        row, sims = res
        ws.cell(row, DEFECT_COL).value = sims
        updated += 1

wb.save(EXCEL_FILE)

# -------------------------------------------------
# SUMMARY
# -------------------------------------------------
print("\n================ SUMMARY ================")
print(f"Total Tests : {ws.max_row - 1}")
print(f"Rows updated: {updated}")
print("[SUCCESS] Done (Parallel + optimized)")