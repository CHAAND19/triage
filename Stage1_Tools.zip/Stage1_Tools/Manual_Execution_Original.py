import sys
import openpyxl
from openpyxl.styles import PatternFill, Font
from copy import copy
import re


# ============================================================
# INPUTS FROM GUI
# ============================================================
# argv[1] -> Triage Template File
# argv[2] -> Manual Execution Input File
# argv[3] -> Output File (absolute path)

TEMPLATE_FILE = sys.argv[1]
INPUT_FILE = sys.argv[2]
OUTPUT_FILE = sys.argv[3]
print("Manual execution output file:", OUTPUT_FILE)
# ============================================================
# LOAD WORKBOOKS
# ============================================================

print("\nLoading Excel files...")
print("Template :", TEMPLATE_FILE)
print("Input    :", INPUT_FILE)

src_wb = openpyxl.load_workbook(INPUT_FILE)
template_wb = openpyxl.load_workbook(TEMPLATE_FILE)
# ============================================================
# AUTO-DETECT MANUAL EXECUTION SOURCE SHEET
# ============================================================

candidate_sheets = [
    s for s in src_wb.sheetnames
    if s.startswith("AADT-")
]

if not candidate_sheets:
    raise Exception("No manual execution AADT sheet found in input file")

if len(candidate_sheets) > 1:
    raise Exception(
        f"Multiple AADT execution sheets found: {candidate_sheets}. "
        "Cannot auto-detect uniquely."
    )

SOURCE_SHEET = candidate_sheets[0]
print(f"Auto-detected manual source sheet: {SOURCE_SHEET}")

# Source worksheet
src_ws = src_wb[SOURCE_SHEET]



# ------------------------------------------------------------
# DYNAMIC TARGET SHEET NAME (Manual_Execution_AADT-XXXXX)
# ------------------------------------------------------------
match = re.search(r"(AADT-\d+)", SOURCE_SHEET)
EXECUTION_ID = match.group(1) if match else "AADT-UNKNOWN"

TARGET_SHEET = f"Manual_Extract_{EXECUTION_ID}"


# ------------------------------------------------------------
# COLORS FOR PASS / FAIL
# ------------------------------------------------------------
FAIL_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
PASS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
BLACK_FONT = Font(color="000000")


# ------------------------------------------------------------
# DETECT VERDICT
# ------------------------------------------------------------
def detect_verdict(cell):
    """Return Pass/Fail text based on text or color."""

    # If text exists, use it
    if cell.value:
        text = str(cell.value).strip()
        if text in ("Pass", "Fail"):
            return text

    # Otherwise check fill color
    try:
        fill = cell.fill.start_color.rgb
    except:
        fill = None

    if fill in ("FFC7CE", "FFFFC7CE"):
        return "Fail"

    if fill in ("C6EFCE", "FFC6EFCE"):
        return "Pass"

    return ""

def find_header_col(ws, header_name):
    for cell in ws[1]:
        if cell.value and str(cell.value).strip().lower() == header_name.lower():
            return cell.col_idx
    return None

# ------------------------------------------------------------
# COPY SHEET WITH FORMATTING + HYPERLINK + VERDICT COLORS
# ------------------------------------------------------------
def copy_sheet_exact(src_ws, dst_ws):

    TESTID_COL = find_header_col(src_ws, "TestID")
    VERDICT_COL = find_header_col(src_ws, "Verdict")

    # Copy column widths
    for col, dim in src_ws.column_dimensions.items():
        dst_ws.column_dimensions[col].width = dim.width

    # Copy row heights
    for r, dim in src_ws.row_dimensions.items():
        dst_ws.row_dimensions[r].height = dim.height

    # Copy merged cells
    for merged_range in src_ws.merged_cells.ranges:
        dst_ws.merge_cells(str(merged_range))

    # Copy cell-by-cell
    for row in src_ws.iter_rows():
        for cell in row:
            new = dst_ws[cell.coordinate]

            # --------------------------------------------------
            # COLUMN B – TestID column → copy hyperlink
            # --------------------------------------------------
            if cell.col_idx == TESTID_COL:     # Column B
                new.value = cell.value

                if cell.hyperlink:
                    new.hyperlink = cell.hyperlink.target
                    new.font = Font(color="0000EE", underline="single")

                if cell.has_style:
                    new.border = copy(cell.border)
                    new.fill = copy(cell.fill)
                    new.number_format = cell.number_format
                    new.protection = copy(cell.protection)
                    new.alignment = copy(cell.alignment)

                continue

            # --------------------------------------------------
            # COLUMN C – Verdict column
            # --------------------------------------------------
            if cell.col_idx == VERDICT_COL:

                # Header (C1)
                if cell.row == 1:
                    new.value = cell.value or "Verdict"
                    if cell.has_style:
                        new.font = copy(cell.font)
                        new.border = copy(cell.border)
                        new.fill = copy(cell.fill)
                        new.number_format = cell.number_format
                        new.protection = copy(cell.protection)
                        new.alignment = copy(cell.alignment)
                    continue

                # Data rows
                verdict = detect_verdict(cell)
                # verdict = cell.value if cell.value else detect_verdict(cell)

                new.value = verdict

                if verdict == "Fail":
                    new.fill = FAIL_FILL
                    new.font = BLACK_FONT

                elif verdict == "Pass":
                    new.fill = PASS_FILL
                    new.font = BLACK_FONT

                else:
                    new.font = BLACK_FONT

                new.border = copy(cell.border)
                new.alignment = copy(cell.alignment)

                continue

            # --------------------------------------------------
            # NORMAL CELLS
            # --------------------------------------------------
            new.value = cell.value

            if cell.has_style:
                new.font = copy(cell.font)
                new.border = copy(cell.border)
                new.fill = copy(cell.fill)
                new.number_format = cell.number_format
                new.protection = copy(cell.protection)
                new.alignment = copy(cell.alignment)


# ------------------------------------------------------------
# EXECUTION
# ------------------------------------------------------------
print("\nLoading Excel files...")

src_wb = openpyxl.load_workbook(INPUT_FILE)
template_wb = openpyxl.load_workbook(TEMPLATE_FILE)

src_ws = src_wb[SOURCE_SHEET]

# Remove sheet if exists
if TARGET_SHEET in template_wb.sheetnames:
    del template_wb[TARGET_SHEET]

dst_ws = template_wb.create_sheet(TARGET_SHEET)

print(f"Copying into: {TARGET_SHEET}")
copy_sheet_exact(src_ws, dst_ws)

template_wb.save(OUTPUT_FILE)

print("\nCOMPLETED SUCCESSFULLY!")
print("Verdict column visible with colors")
print("TestID Jira hyperlinks preserved")
print("Sheet name:", TARGET_SHEET)
print("Output saved:", OUTPUT_FILE)