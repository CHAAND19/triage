import os
import time
import glob
import shutil
import webbrowser
from tkinter import messagebox

# Where TriWorX will keep copied manual input files
MANUAL_INPUT_DIR = r"C:\JLR\Tools\TriWorX_Full\Manual_Input_Files"

# Default download directory for most browsers on Windows
DOWNLOAD_DIR_DEFAULT = os.path.join(os.path.expanduser("~"), "Downloads")

# Behavior tuning
DOWNLOAD_TIMEOUT_SEC = 180     # 3 minutes
POLL_INTERVAL_SEC = 1.0        # 1 second


def _wait_for_new_excel_file(watch_dirs, since_ts, timeout_sec=180, poll_sec=1.0):
    """
    Watch directories for a newly created/updated .xlsx/.xls/.xlsm file after since_ts.
    Returns the newest matching file path or "" on timeout.
    """
    deadline = time.time() + timeout_sec

    # Snapshot existing files to avoid picking old ones
    existing = set()
    for d in watch_dirs:
        if os.path.isdir(d):
            for ext in ("*.xlsx", "*.xls", "*.xlsm"):
                existing.update(glob.glob(os.path.join(d, ext)))

    while time.time() < deadline:
        candidates = []
        for d in watch_dirs:
            if not os.path.isdir(d):
                continue

            for ext in ("*.xlsx", "*.xls", "*.xlsm"):
                for f in glob.glob(os.path.join(d, ext)):
                    try:
                        if f in existing:
                            continue
                        if os.path.getmtime(f) >= since_ts:
                            candidates.append(f)
                    except OSError:
                        continue

        if candidates:
            return max(candidates, key=lambda p: os.path.getmtime(p))

        time.sleep(poll_sec)

    return ""


def _copy_to_manual_input_folder(src_path: str, job_id: str) -> str:
    """
    Copy downloaded file into MANUAL_INPUT_DIR with a helpful prefix.
    Returns destination path.
    """
    os.makedirs(MANUAL_INPUT_DIR, exist_ok=True)

    base = os.path.basename(src_path)
    if job_id and not base.startswith(job_id):
        base = f"{job_id}_{base}"

    dst_path = os.path.join(MANUAL_INPUT_DIR, base)
    shutil.copy2(src_path, dst_path)
    return dst_path


def ensure_manual_input_file(job: dict) -> str:
    """
    Option-4 baseline:
    - Opens report_link in browser
    - User downloads Excel via SSO
    - TriWorX detects the new download and copies to MANUAL_INPUT_DIR
    - Updates job['execution']['manual_input_file'] with the copied path
    Returns the local manual_input_file path, or "" if not obtained.
    """

    exec_data = job.get("execution", {})
    job_id = job.get("job_id", "AADT-UNKNOWN")

    # If already set and exists, accept it
    existing = (exec_data.get("manual_input_file") or "").strip()
    if existing and os.path.exists(existing):
        return existing

    report_link = exec_data.get("report_link") or exec_data.get("evidence", {}).get("link", "")
    report_link = (report_link or "").strip()

    if not report_link:
        messagebox.showwarning(
            "TriWorX – Manual Job",
            f"Job {job_id} has no Report link.\nCannot obtain manual input file."
        )
        return ""

    os.makedirs(MANUAL_INPUT_DIR, exist_ok=True)

    messagebox.showinfo(
        "TriWorX – Manual Job",
        "Manual input file will be downloaded via your browser (SSO).\n\n"
        f"1) Browser will open the report link.\n"
        f"2) Download the Excel file.\n"
        f"3) TriWorX will detect the new download and copy it into:\n"
        f"   {MANUAL_INPUT_DIR}\n\n"
        f"Waiting up to {DOWNLOAD_TIMEOUT_SEC} seconds..."
    )

    # Open in browser (SSO handled by browser)
    webbrowser.open(report_link)

    watch_dir = os.environ.get("TRIWORX_DOWNLOAD_DIR", DOWNLOAD_DIR_DEFAULT)
    watch_dirs = [MANUAL_INPUT_DIR, watch_dir]

    t0 = time.time()
    downloaded_path = _wait_for_new_excel_file(
        watch_dirs=watch_dirs,
        since_ts=t0,
        timeout_sec=DOWNLOAD_TIMEOUT_SEC,
        poll_sec=POLL_INTERVAL_SEC
    )

    if not downloaded_path:
        messagebox.showwarning(
            "TriWorX – Manual Job",
            "No new Excel download detected.\n"
            "Please download the Excel file and try again."
        )
        return ""

    try:
        # If file is already inside MANUAL_INPUT_DIR, use it; else copy it in
        if os.path.dirname(downloaded_path).rstrip("\\/") == MANUAL_INPUT_DIR.rstrip("\\/"):
            final_path = downloaded_path
        else:
            final_path = _copy_to_manual_input_folder(downloaded_path, job_id)

        exec_data["manual_input_file"] = final_path
        job["execution"] = exec_data
        return final_path

    except Exception as e:
        messagebox.showerror("TriWorX – Manual Copy Failed", str(e))
        return ""