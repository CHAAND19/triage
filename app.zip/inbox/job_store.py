"""
Job Store for TriWorX Inbox (STEP-3)

Stores parsed triage jobs in memory.
Defensive against None jobs (non-triage mails).
"""

from typing import Dict, List


class JobStore:
    def __init__(self):
        # job_id -> job dict
        self._jobs: Dict[str, dict] = {}

    # ------------------
    # Core operations
    # ------------------

    def add_job(self, job: dict) -> None:
        """
        Add or update a single job.
        """
        if not job:
            return

        job_id = job.get("job_id")
        if not job_id:
            raise ValueError("Job must contain job_id")

        self._jobs[job_id] = job

    def add_jobs(self, jobs: List[dict]) -> None:
        """
        Add multiple jobs safely.
        Ignores None entries.
        """
        for job in jobs:
            if job:
                self.add_job(job)

    def get_job(self, job_id: str) -> dict | None:
        """
        Retrieve a job by job_id.
        """
        return self._jobs.get(job_id)

    def list_jobs(self) -> List[dict]:
        """
        Return all stored jobs.
        """
        return list(self._jobs.values())

    # ------------------
    # Utilities
    # ------------------

    def clear(self) -> None:
        """
        Remove all jobs from the store.
        """
        self._jobs.clear()

    def has_jobs(self) -> bool:
        """
        Check if store contains any jobs.
        """
        return bool(self._jobs)