"""
STEP‑3.2: Inbox UI (UI‑1)

Displays parsed triage jobs from JobStore.
Selection only; execution is wired in STEP‑3.3.
"""

import tkinter as tk
import threading
from tkinter import ttk, messagebox

from triworx.inbox.job_store import JobStore
from triworx.core.stage_engine import StageEngine
from triworx.inbox.outlook_reader import read_selected_outlook_mails
from triworx.inbox.job_launcher import launch_job
from triworx.inbox.mail_parser import parse_mail

from triworx.inbox.job_launcher import run_stage1_headless  # add to imports

class InboxUI:
    def __init__(self, job_store: JobStore):
        self.job_store = job_store

        self.root = tk.Tk()
        self.root.title("TriWorX – TRIage WORkflow eXecutor")
        self.root.geometry("900x420")

        self._build_ui()
        self._populate()

    # =========================
    # UI Construction
    # =========================

    def _build_ui(self):
        columns = (
            "job_id",
            "execution_type",
            "sw_component",
            "rig_id",
            "pass_count",
            "fail_count",
            "status",
        )

        self.tree = ttk.Treeview(
            self.root,
            columns=columns,
            show="headings",
            selectmode="extended",
        )

        self.tree.heading("job_id", text="Job ID")
        self.tree.heading("execution_type", text="Type")
        self.tree.heading("sw_component", text="SW Component")
        self.tree.heading("rig_id", text="Rig")
        self.tree.heading("pass_count", text="Pass")
        self.tree.heading("fail_count", text="Fail")

        self.tree.heading("status", text="Status")

        self.tree.column("job_id", width=200)
        self.tree.column("execution_type", width=120)
        self.tree.column("sw_component", width=160)
        self.tree.column("rig_id", width=120)
        self.tree.column("pass_count", width=80, anchor="center")
        self.tree.column("fail_count", width=80, anchor="center")

        self.tree.column("status", width=120)

        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        button_bar = tk.Frame(self.root)
        button_bar.pack(fill=tk.X, padx=10, pady=(0, 10))

        tk.Button(
            button_bar,
            text="Refresh",
            width=12,
            command=self._refresh
        ).pack(side=tk.LEFT)

        tk.Button(
            button_bar,
            text="Initiate Batch Job",
            width=18,
            command=self._initiate_batch_job
        ).pack(side=tk.RIGHT, padx=6)

        tk.Button(
            button_bar,
            text="Open Job",
            width=12,
            command=self._open_job
        ).pack(side=tk.RIGHT)

    # =========================
    # Data Handling
    # =========================

    def _populate(self):
        self.tree.delete(*self.tree.get_children())

        for job in self.job_store.list_jobs():
            exec_data = job["execution"]
            status = self._job_status(job)

            self.tree.insert(
                "",
                tk.END,
                iid=job["job_id"],
                values=(
                    job["job_id"],
                    exec_data["execution_type"],
                    exec_data["sw_component"],
                    exec_data["rig_id"],
                    exec_data.get("pass_count", 0),
                    exec_data.get("fail_count", 0),
                    status,
                ),
            )

    def _job_status(self, job: dict) -> str:
        if job["execution"]["execution_type"] == "MANUAL":
            return "Needs file"
        return "Ready"

    # =========================
    # Actions
    # =========================

    def _refresh(self):
        try:
            mails = read_selected_outlook_mails()

            jobs = []
            ignored_count = 0

            for mail in mails:
                parsed = parse_mail(mail)
                if parsed:
                    jobs.append(parsed)
                else:
                    ignored_count += 1

            self.job_store.clear()
            self.job_store.add_jobs(jobs)
            self._populate()

            if jobs and ignored_count:
                message = (
                    f"Refresh completed: {len(jobs)} job(s) loaded, "
                    f"{ignored_count} mail(s) ignored (non‑triage)."
                )
            elif jobs:
                message = f"Refresh completed: {len(jobs)} job(s) loaded."
            else:
                message = (
                    f"Refresh completed: No triage jobs found "
                    f"({ignored_count} mail(s) ignored)."
                )

            messagebox.showinfo("TriWorX – Refresh", message)

        except Exception as exc:
            messagebox.showerror("TriWorX – Refresh failed", str(exc))

    def _open_job(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("TriWorX", "Please select a job.")
            return

        if len(selection) > 1:
            messagebox.showwarning(
                "TriWorX",
                "Multiple jobs selected.\n"
                "Use 'Initiate Batch Job' for batch execution."
            )
            return

        job_id = selection[0]
        job = self.job_store.get_job(job_id)

        if not job:
            messagebox.showerror("TriWorX – Error", "Selected job not found.")
            return

        launch_job(job)


    def _initiate_batch_job(self):
        selection = self.tree.selection()

        if not selection or len(selection) < 2:
            messagebox.showwarning("Batch Job", "Please select at least two jobs.")
            return

        if not messagebox.askyesno(
            "Confirm Batch Job",
            f"Run Stage‑1 automatically for {len(selection)} selected jobs?"
        ):
            return

        def worker(job_ids):
            results = []

            for job_id in job_ids:
                job = self.job_store.get_job(job_id)
                if not job:
                    results.append((job_id, False, "Job not found"))
                    continue

                try:
                    out_file = run_stage1_headless(job)

                    exec_ctx = job["execution"]

                    # ✅ CRITICAL FIX
                    exec_ctx["output_file"] = out_file
                    # ✅ MATCH GUI BEHAVIOR EXACTLY (copy logic, don't change anything else)
                    try:
                        import json
                        import os
                        from tools_pipeline.Stage2_Tools.triage_flow.html_report import download_html_evidence

                        test_execution_ids = [exec_ctx.get("test_execution_id")]

                        exec_ctx.setdefault("stage2", {})
                        exec_ctx["stage2"]["flow_report_paths"] = []

                        base_output = out_file

                        for te_id in test_execution_ids:

                            print(f"[BATCH] Processing TE → {te_id}")

                            meta_path = base_output.replace(".xlsx", "_meta.json")

                            print("[BATCH] Looking for meta file:", meta_path)

                            if not os.path.exists(meta_path):
                                raise Exception(f"Meta file not found for {te_id}")

                            with open(meta_path, "r") as f:
                                meta = json.load(f)

                            evidence_links = meta.get("evidence_links", [])

                            download_dir = os.path.join(
                                "C:\\JLR\\Tools\\TriWorX_Full\\stage2_reports",
                                te_id
                            )

                            html_files = download_html_evidence(
                                evidence_links,
                                download_dir,
                                te_id
                            )

                            if not html_files:
                                raise Exception(f"HTML download failed for {te_id}")

                            exec_ctx["stage2"]["flow_report_paths"].append(html_files[0])

                        # ✅ required exactly like GUI
                        exec_ctx["stage2"]["flow_report_path"] = exec_ctx["stage2"]["flow_report_paths"][0]

                        print(f"[BATCH] HTML ready: {exec_ctx['stage2']['flow_report_path']}")
                        # ✅ FINAL STEP — trigger Stage‑2 (same as UI button)

                        try:
                            import subprocess, sys, os

                            excel_file = exec_ctx.get("output_file")
                            html_path = exec_ctx["stage2"]["flow_report_path"]

                            base, ext = os.path.splitext(excel_file)
                            out_file = base + "_stage2" + ext

                            te = exec_ctx.get("test_execution_id", "UNKNOWN")

                            log_path = os.path.join(
                                r"C:\\JLR\\Tools\\TriWorX_Full\\logs",
                                f"stage2_flow_{te}.log"
                            )

                            summary_path = os.path.join(
                                r"C:\\JLR\\Tools\\TriWorX_Full\\logs",
                                f"stage2_flow_summary_{te}.json"
                            )

                            cmd = [
                                sys.executable,
                                "tools_pipeline/Stage2_Tools/triworx_stage2_flow_entry.py",
                                "--excel", excel_file,
                                "--report", html_path,
                                "--out", out_file,
                                "--log", log_path,
                                "--summary", summary_path,
                                "--verdict-sheet", te
                            ]

                            print(f"[BATCH] EXEC STAGE-2 CMD for {te}:", cmd)

                            result = subprocess.run(cmd, capture_output=True, text=True)

                            print(result.stdout)
                            print(result.stderr)

                            if result.returncode != 0:
                                raise Exception(f"Stage‑2 failed for {te}")

                            print(f"[BATCH] Stage‑2 COMPLETED for {te}")
                        except Exception as e:
                            print("[BATCH] Stage‑2 FAILED:", e)
                    except Exception as e:
                        print("[BATCH] HTML preparation failed:", e)


                    # ✅ Enable Stage‑2 UI from main thread
                    def enable_stage2():
                        try:
                            # pass execution context to main GUI
                            from triworx.ui.triworx_gui import TriWorXGUI

                            # ✅ IMPORTANT: you must already have GUI instance running
                            # so instead call method on existing GUI (see NOTE below)

                            if hasattr(self.root, "main_gui"):
                                gui = self.root.main_gui

                                gui.execution_context = {"execution": exec_ctx}
                                gui.stage_engine = StageEngine({"execution": exec_ctx})

                                if exec_ctx.get("execution_type") == "AUTOMATED":
                                    gui._prepare_stage2_defaults()
                                    gui._set_stage2_enabled(True)

                        except Exception as e:
                            print("Stage‑2 enable failed:", e)

                    self.root.after(0, enable_stage2)

                    results.append((job_id, True, out_file))

                except Exception as e:
                    results.append((job_id, False, str(e)))

            def show_summary():
                ok = [r for r in results if r[1]]
                bad = [r for r in results if not r[1]]

                lines = [
                    "Batch Stage‑1 finished.",
                    f"Success: {len(ok)}",
                    f"Failed : {len(bad)}",
                    "",
                ]

                if ok:
                    lines.append("✅ Outputs:")
                    for job_id, _, out in ok[:10]:
                        lines.append(f"- {job_id}: {out}")

                if bad:
                    lines.append("")
                    lines.append("❌ Failures:")
                    for job_id, _, err in bad[:10]:
                        lines.append(f"- {job_id}: {err}")

                messagebox.showinfo("TriWorX – Batch Summary", "\n".join(lines))

            self.root.after(0, show_summary)

        threading.Thread(target=worker, args=(list(selection),), daemon=True).start()


    def run(self):
        self.root.mainloop()