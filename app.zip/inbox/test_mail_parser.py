from triworx.inbox.outlook_reader import read_selected_outlook_mails
from triworx.inbox.mail_parser import parse_mail

mails = read_selected_outlook_mails()
print(f"Parsing {len(mails)} mails...\n")

for raw in mails:
    job = parse_mail(raw)
    print("=" * 80)
    print("JOB ID:", job["job_id"])
    print("TYPE  :", job["execution"]["execution_type"])
    print("COMP  :", job["execution"]["sw_component"])
    print("TAMS  :", job["execution"]["rig_id"])
    print("PLAN  :", job["execution"]["test_plan_id"])
    print("EVID  :", job["execution"]["evidence"]["link"])
    print("PASS  :", job["execution"]["pass_count"])
    print("FAIL  :", job["execution"]["fail_count"])
