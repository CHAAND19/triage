import re
from html.parser import HTMLParser


# =========================
# Helpers
# =========================

AADT_PATTERN = re.compile(r"AADT-\d+")
TAMS_PATTERN = re.compile(r"TAMS-\d+")


class SimpleTableHTMLParser(HTMLParser):
    """
    Minimal HTML table parser for key-value tables like:
    Test Plan | AADT-245706
    """
    def __init__(self):
        super().__init__()
        self.in_td = False
        self.current_row = []
        self.rows = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() in ("td", "th"):
            self.in_td = True

    def handle_endtag(self, tag):
        if tag.lower() in ("td", "th"):
            self.in_td = False
        if tag.lower() == "tr" and self.current_row:
            self.rows.append(self.current_row)
            self.current_row = []

    def handle_data(self, data):
        if self.in_td:
            text = data.strip()
            if text:
                self.current_row.append(text)


def _extract_kv_from_html(html_body: str) -> dict:
    """
    Extract key-value pairs from the execution table.
    """
    parser = SimpleTableHTMLParser()
    parser.feed(html_body)

    kv = {}
    for row in parser.rows:
        if len(row) >= 2:
            key = row[0].strip().rstrip(":")
            value = row[1].strip()
            kv[key] = value

    return kv

def _extract_pass_fail_from_text(text: str):
    pass_count = 0
    fail_count = 0

    if not text:
        return pass_count, fail_count

    # ✅ robust patterns (handles Pass 23, Pass: 23, PASS 23 etc.)
    pass_match = re.search(r"pass[:\s]+(\d+)", text, re.IGNORECASE)
    fail_match = re.search(r"fail[:\s]+(\d+)", text, re.IGNORECASE)

    if pass_match:
        pass_count = int(pass_match.group(1))

    if fail_match:
        fail_count = int(fail_match.group(1))

    return pass_count, fail_count

# =========================
# Main parser
# =========================

def parse_mail(raw_mail: dict) -> dict:
    """
    Parse a raw mail (STEP-1 output) into a normalized Triage Job.

    Correction:
    - "Report" in the mail is ALWAYS a link.
    - We store it in one unified field: execution["report_link"].
    - Meaning depends on execution_type:
        AUTOMATED => report_link is automation report/evidence URL
        MANUAL    => report_link is manual-input source URL (still needs local manual_input_file later)
    - For backward compatibility, we also mirror this into execution["evidence"]["link"].
    """
    subject = raw_mail["subject"]
    html_body = raw_mail.get("html_body", "")

    # ---------
    # Subject parsing (SAFE)
    # ---------
    aadt_matches = AADT_PATTERN.findall(subject)
    tams_match = TAMS_PATTERN.search(subject)

    # Not a triage mail → silently ignore
    if not aadt_matches:
        return None

    test_execution_id = aadt_matches[0]
    rig_id = tams_match.group(0) if tams_match else ""

    is_manual = "manual" in subject.lower()
    execution_type = "MANUAL" if is_manual else "AUTOMATED"

    sw_component = ""
    subject_parts = subject.split(" - ")
    if len(subject_parts) >= 2:
        tail = subject_parts[1]
        tail = tail.replace("Manual", "").replace("Automated", "").strip()
        sw_component = tail.split()[0] if tail else ""

    # ---------
    # HTML table parsing
    # ---------
    kv = _extract_kv_from_html(html_body)

    # Extract Pass/Fail from table


    try:
        kv_normalized = {k.strip().lower(): v for k, v in kv.items()}

        pass_count = int(kv_normalized.get("pass", 0))
        fail_count = int(kv_normalized.get("fail", 0))
    except Exception:
        pass_count, fail_count = 0, 0




    test_plan_id = kv.get("Test Plan", "")
    report_link = kv.get("Report", "")  # ✅ Always a link (manual or automated)

    # ---------
    # Build normalized job
    # ---------
    job = {
        "job_id": test_execution_id,
        "execution": {
            "test_plan_id": test_plan_id,
            "test_execution_id": test_execution_id,
            "execution_type": execution_type,
            "rig_id": rig_id,
            "sw_component": sw_component,

            # ✅ Unified field: always the link from mail "Report"
            "report_link": report_link,

            # ✅ Backward compatible mirror (so existing code using evidence.link keeps working)
            "evidence": {
                "type": execution_type,
                "link": report_link,
            },

            # Manual jobs still need a LOCAL file path later; link is only the source/reference
            "manual_input_file": "",

            # Keep your structured sw_version model
            "sw_version": {
                "value": "",
                "source": "MANUAL_EXCEL" if execution_type == "MANUAL" else "USER",
                "status": "DEFERRED" if execution_type == "MANUAL" else "MISSING",
            },
            
            "pass_count": pass_count,
            "fail_count": fail_count,

        },
        "meta": {
            "sender": raw_mail.get("sender", ""),
            "received_time": raw_mail.get("received_time"),
            "subject": subject,
        },
        "state": "NEW",
    }

    return job