import win32com.client


class OutlookReaderError(Exception):
    pass


def read_selected_outlook_mails():
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        explorer = outlook.ActiveExplorer()
    except Exception as exc:
        raise OutlookReaderError("Unable to connect to Outlook") from exc

    if explorer is None:
        raise OutlookReaderError(
            "No active Outlook Explorer found.\n"
            "Please open Outlook Inbox, click any mail row, and try again."
        )

    selection = explorer.Selection
    mails = []

    for item in selection:
        try:
            entry_id = getattr(item, "EntryID", None)
            subject = getattr(item, "Subject", None)

            if entry_id is None or subject is None:
                continue

            mails.append({
                "entry_id": entry_id,
                "subject": subject or "",
                "body": getattr(item, "Body", "") or "",
                "html_body": getattr(item, "HTMLBody", "") or "",
                "sender": getattr(item, "SenderName", "") or "",
                "received_time": getattr(item, "ReceivedTime", None),
            })

        except Exception:
            continue

    return mails