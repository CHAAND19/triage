from triworx.inbox.outlook_reader import read_selected_outlook_mails
from triworx.inbox.mail_parser import parse_mail
from triworx.inbox.job_store import JobStore
from triworx.inbox.inbox_ui import InboxUI


# STEP‑1: Read mails from Outlook
mails = read_selected_outlook_mails()

# STEP‑2: Parse mails into jobs
jobs = [parse_mail(m) for m in mails]

# STEP‑3.1: Store jobs
store = JobStore()
store.add_jobs(jobs)

# STEP‑3.2: Launch Inbox UI
ui = InboxUI(store)
ui.run() 