print("SCRIPT STARTED")

from triworx.inbox.outlook_reader import read_selected_outlook_mails

print("Imported reader")

mails = read_selected_outlook_mails()
print("Reader executed")

print(f"Number of mails read: {len(mails)}")

for mail in mails:
    print("-" * 50)
    print("Subject:", mail["subject"])
    print("Sender:", mail["sender"])
    print("Received:", mail["received_time"])

print("SCRIPT FINISHED")