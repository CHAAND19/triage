
import os
from datetime import datetime
import tkinter as tk
import win32com.client
from tkinter import messagebox

from triworx.ui.triworx_gui import TriWorXGUI
from triworx.core.stage_engine import StageEngine
from triworx.inbox.manual_helpers import ensure_manual_input_file
import urllib.request
import urllib.parse

MANUAL_INPUT_DIR = r"C:\JLR\Tools\TriWorX_Full\Manual_Input_Files"
OUTPUT_BASE_DIR = r"C:\JLR\Tools\TriWorX_Full\Generated_L0_TriageFiles"
DEFAULT_TEMPLATE_PATH = "templates/L0_Triage_Report_XX_XX_XXXX_TP_AADT-XXXXXX_TE_AADT-XXXXXX.xlsx"
DEFAULT_SW_VERSION = "DADC_Drop11.2_master_26.20.16"



def _safe_filename_from_url(url: str, fallback: str) -> str:
    try:
        path = urllib.parse.urlparse(url).path
        name = os.path.basename(path)
        if not name:
            return fallback
        # strip query-style suffixes if any
        return name.split("?")[0]
    except Exception:
        return fallback

def _force_download_url(url: str) -> str:
    # Common SharePoint patterns
    if "download=1" in url:
        return url
    if "?" in url:
        return url + "&download=1"
    return url + "?download=1"

def download_sharepoint_excel(report_link: str, job_id: str) -> str:
    """
    Download SharePoint-hosted Excel referenced by report_link into MANUAL_INPUT_DIR.
    Returns local file path.

    Supports optional auth via env vars:
      - TRIWORX_SP_BEARER  (Bearer token)
      - TRIWORX_SP_COOKIE  (Cookie header)
    """
    if not report_link:
        raise RuntimeError("Report link is empty; cannot download manual input.")

    os.makedirs(MANUAL_INPUT_DIR, exist_ok=True)
    report_link = _force_download_url(report_link)

    fname = _safe_filename_from_url(report_link, f"{job_id}_manual.xlsx")
    # Ensure .xlsx if not present
    if not fname.lower().endswith((".xlsx", ".xls")):
        fname = f"{job_id}_manual.xlsx"

    local_path = os.path.join(MANUAL_INPUT_DIR, fname)

    # Build request with optional headers
    req = urllib.request.Request(report_link)
    bearer = os.environ.get("TRIWORX_SP_BEARER", "").strip()
    cookie = os.environ.get("TRIWORX_SP_COOKIE", "").strip()
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
    if cookie:
        req.add_header("Cookie", cookie)
    req.add_header("User-Agent", "TriWorX/1.0")

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            content_type = (resp.headers.get("Content-Type") or "").lower()
            data = resp.read()

        # Detect common auth/login HTML responses
        if "text/html" in content_type and len(data) < 200_000:
            raise RuntimeError(
                "SharePoint download returned HTML (likely auth/SSO page). "
                "Use a direct download link or provide TRIWORX_SP_BEARER/TRIWORX_SP_COOKIE."
            )

        with open(local_path, "wb") as f:
            f.write(data)

        # sanity check
        if os.path.getsize(local_path) == 0:
            raise RuntimeError("Downloaded file is empty.")

        return local_path

    except Exception as e:
        raise RuntimeError(f"Manual input download failed: {e}")
    
def _compute_output_file(test_plan_id: str, test_execution_id: str) -> str:
    today = datetime.now().strftime("%d_%m_%Y")
    filename = f"L0_Triage_Report_{today}_TP_{test_plan_id}_TE_{test_execution_id}.xlsx"
    return os.path.join(OUTPUT_BASE_DIR, filename)

def run_stage1_headless(job: dict) -> str:
    exec_data = job.get("execution", {})
    exec_type = (exec_data.get("execution_type") or "").strip().upper()

    # automated-only workaround stays intact for batch
    if exec_type != "AUTOMATED":
        raise RuntimeError("Batch Stage‑1 supports AUTOMATED only (MANUAL deferred).")

    tp = (exec_data.get("test_plan_id") or "").strip()
    te = (exec_data.get("test_execution_id") or "").strip()
    if not tp or not te:
        raise RuntimeError("Missing test_plan_id or test_execution_id")

    # sw_version normalize
    sw = exec_data.get("sw_version", "")
    if isinstance(sw, dict):
        sw = sw.get("value", "")
    if not str(sw).strip():
        sw = DEFAULT_SW_VERSION

    template_path = exec_data.get("template_path") or DEFAULT_TEMPLATE_PATH

    # fixed folder, dynamic filename
    existing_out = exec_data.get("output_file", "")
    if existing_out:
        out_file = os.path.join(OUTPUT_BASE_DIR, os.path.basename(existing_out))
    else:
        out_file = _compute_output_file(tp, te)

    execution_context = {
        "execution": {
            **exec_data,
            "test_plan_id": tp,
            "test_execution_id": te,
            "execution_type": exec_type,
            "template_path": template_path,
            "output_file": out_file,
            "sw_version": sw,
        }
    }

    StageEngine(execution_context).execute_stage(1)
    return out_file
def launch_job(job: dict):
    """
    Entry point from Inbox UI.

    - Opens TriWorX GUI
    - Does NOT assume output_file exists yet (we compute it safely here)
    """

    exec_data = job.get("execution", {})

    # ✅ FIX 4: normalize execution_type once, early
    exec_type = (exec_data.get("execution_type") or "").strip().upper()
    if exec_type not in ("AUTOMATED", "MANUAL"):
        exec_type = "AUTOMATED"

    # -------------------------------------------------
    # Pre-launch validation for MANUAL jobs (message only)
    # -------------------------------------------------
    if exec_type == "MANUAL":
        manual_file = exec_data.get("manual_input_file", "")
        if not manual_file:
            messagebox.showwarning(
                "TriWorX – Manual Job",
                "Manual input file is missing.\n\n"
                "TriWorX will attempt to fetch it using the report link.\n"
                "If it cannot be fetched, Register Execution will block."
            )

    # -------------------------------------------------
    # ✅ Ensure output_file is ALWAYS set (fixed folder, dynamic filename)
    # -------------------------------------------------
    test_plan_id = exec_data.get("test_plan_id", "")
    test_execution_id = exec_data.get("test_execution_id", "")

    existing_output = exec_data.get("output_file", "")
    if existing_output:
        output_filename = os.path.basename(existing_output)
    else:
        today = datetime.now().strftime("%d_%m_%Y")
        output_filename = f"L0_Triage_Report_{today}_TP_{test_plan_id}_TE_{test_execution_id}.xlsx"

    output_file = os.path.join(OUTPUT_BASE_DIR, output_filename)

    # -------------------------------------------------
    # ✅ Ensure template_path is never None
    # -------------------------------------------------
    template_path = exec_data.get("template_path") or (
        "templates/L0_Triage_Report_XX_XX_XXXX_TP_AADT-XXXXXX_TE_AADT-XXXXXX.xlsx"
    )

    # -------------------------------------------------
    # MANUAL: Option 4 helper (browser download -> detect -> copy)
    # -------------------------------------------------
    if exec_type == "MANUAL":
        ensure_manual_input_file(job)
        # ✅ CRITICAL: refresh exec_data so UI gets updated manual_input_file
        exec_data = job.get("execution", {})

    # -------------------------------------------------
    # Build execution data for intake UI
    # -------------------------------------------------
    mail_input = {
        "test_plan_id": test_plan_id,
        "test_execution_id": test_execution_id,
        "execution_type": exec_type,  # ✅ always canonical
        "rig_id": exec_data.get("rig_id", ""),
        "sw_version": exec_data.get("sw_version", ""),
        "sw_component": exec_data.get("sw_component", ""),
        "report_link": exec_data.get("report_link") or exec_data.get("evidence", {}).get("link", ""),
        "manual_input_file": exec_data.get("manual_input_file", ""),  # ✅ now updated after helper
        "template_path": template_path,
        "output_file": output_file,
    }

    root = tk.Tk()
    ui = TriWorXGUI(root)
    ui.populate_intake_from_mail(mail_input)
    root.mainloop()

def reply_all_with_block_reason(job: dict, reason: str):
    """
    Temporary placeholder:
    We are deferring Outlook Reply-All automation.
    For now, show a clear message to the user.
    """
    job_id = job.get("job_id", "UNKNOWN")
    messagebox.showwarning(
        "TriWorX – Manual Job Blocked",
        f"Job {job_id} cannot be executed.\n\nReason:\n{reason}\n\n"
        "Please provide the manual input file and try again."
    )