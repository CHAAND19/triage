from triworx.inbox.job_store import JobStore

store = JobStore()

store.add_job({"job_id": "AADT-123", "state": "NEW"})
store.add_job({"job_id": "AADT-456", "state": "NEW"})

print("Jobs in store:")
for job in store.list_jobs():
    print(job["job_id"])