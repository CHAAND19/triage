import tkinter as tk
from tkinter import messagebox, filedialog
from tkinter import ttk
import re


class MailIntakePanel:
    def __init__(self, parent, on_register_callback):
        self.on_register_callback = on_register_callback

        # Always store mail Report URL here (unified)
        self._report_link_from_mail = ""

        self.frame = tk.Frame(parent, bd=1, relief="solid", padx=8, pady=6)
        self.frame.pack(fill="x", padx=5, pady=5)

        tk.Label(
            self.frame,
            text="Execution Intake (From Mail)",
            font=("Arial", 11, "bold")
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=4)

        self.entries = {}

        self._add_entry("test_plan_id", "Test Plan ID", 1)
        self._add_entry("test_execution_id", "Test Execution ID", 2)

        # Execution Type
        tk.Label(self.frame, text="Execution Type (AUTOMATED / MANUAL)").grid(row=3, column=0, sticky="w")
        self.execution_type_var = tk.StringVar(value="AUTOMATED")
        self.execution_type_cb = ttk.Combobox(
            self.frame,
            textvariable=self.execution_type_var,
            values=["AUTOMATED", "MANUAL"],
            state="readonly",
            width=57
        )
        self.execution_type_cb.grid(row=3, column=1, sticky="w")
        self.execution_type_cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_mode_ui())

        self._add_entry("rig_id", "Rig / TAMS ID", 4)
        self._add_entry("sw_version", "SW Version", 5)
        self._add_entry("sw_component", "SW Component", 6)
        
        # Report / Evidence
        tk.Label(self.frame, text="Report / Evidence").grid(row=7, column=0, sticky="w")
        self.report_value_var = tk.StringVar()
        self.report_value_entry = tk.Entry(self.frame, width=60, textvariable=self.report_value_var)
        self.report_value_entry.grid(row=7, column=1, sticky="w")

        self.browse_btn = tk.Button(self.frame, text="Browse", command=self._browse_file)
        self.browse_btn.grid(row=7, column=2, padx=4)

        self._add_entry("template_path", "Template File Path", 8)

        # Output path fixed, read-only
        tk.Label(self.frame, text="Output File Path").grid(row=9, column=0, sticky="w")
        output_entry = tk.Entry(self.frame, width=60, state="readonly")
        output_entry.grid(row=9, column=1, sticky="w")
        self.entries["output_file"] = output_entry

        tk.Button(
            self.frame,
            text="✔ Register Execution",
            command=self.register_execution
        ).grid(row=10, column=1, sticky="e", pady=6)


        self._refresh_mode_ui()

    def _add_entry(self, key, label, row):
        tk.Label(self.frame, text=label).grid(row=row, column=0, sticky="w")
        entry = tk.Entry(self.frame, width=60)
        entry.grid(row=row, column=1, sticky="w")
        self.entries[key] = entry

    # ---------------------------------------------------------
    # ✅ Populate from mail/job launcher input (safe & consistent)
    # ---------------------------------------------------------
    def populate_from_mail(self, mail_data: dict):
        # ✅ Save mail Report URL always (unified key) with fallback for older jobs
        self._report_link_from_mail = str(
            (mail_data.get("report_link") or "") or
            (mail_data.get("evidence", {}).get("link") or "")
        ).strip()

        # Fill base entries safely: clear first, always insert strings
        for key, entry in self.entries.items():
            value = mail_data.get(key, "")
            if isinstance(value, dict):
                value = value.get("value", "")
            if value is None:
                value = ""

            if key == "output_file":
                entry.config(state="normal")
                entry.delete(0, tk.END)
                entry.insert(0, str(value))
                entry.config(state="readonly")
            else:
                entry.delete(0, tk.END)
                entry.insert(0, str(value))

        # ✅ Execution type: normalize + clamp to allowed values
        mode = str(mail_data.get("execution_type", "AUTOMATED")).strip().upper()
        if mode not in ("AUTOMATED", "MANUAL"):
            mode = "AUTOMATED"


        self.execution_type_var.set(mode)
        self.execution_type_cb.set(mode)   # ✅ FORCE combobox to display the value
        self._refresh_mode_ui()



        # Report/Evidence field display depends on mode:
        mode = self.execution_type_var.get().strip().upper()

        if mode == "MANUAL":
            # Show the downloaded local manual file path
            self.report_value_var.set(str(mail_data.get("manual_input_file", "") or ""))
        else:
            # Show the report/evidence link
            self.report_value_var.set(self._report_link_from_mail)

        
    def _browse_file(self):
        path = filedialog.askopenfilename(
            title="Select Manual Input File",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
        )
        if path:
            # MANUAL: browsing sets local file path into the same field
            self.report_value_var.set(path)

    def _refresh_mode_ui(self):
        # ✅ No browse allowed in any mode
        self.browse_btn.config(state="disabled")
        self.report_value_entry.config(state="normal")

    # ---------------------------------------------------------
    # ✅ Register: interpret report_link by execution_type
    # ---------------------------------------------------------
    def register_execution(self):
        missing = []
        data = {}

        exec_type = self.execution_type_var.get().strip().upper()
        data["execution_type"] = exec_type

        # Required base fields
        required = [
            "test_plan_id", "test_execution_id",
            "rig_id", "sw_component", "template_path"
        ]

        # sw_version required only for AUTOMATED (manual can remain deferred)
        if exec_type == "AUTOMATED":
            required.append("sw_version")

        for k in required:
            v = self.entries[k].get().strip()
            if not v:
                missing.append(k)
            data[k] = v

        # output_file should be present (computed upstream)
        data["output_file"] = self.entries["output_file"].get().strip()
        if not data["output_file"]:
            missing.append("output_file")

        # Now interpret the Report/Evidence field based on type
        field_val = self.report_value_var.get().strip()

        if exec_type == "AUTOMATED":
            # Report/Evidence field contains URL
            data["report_link"] = field_val
            data["manual_input_file"] = ""

        else:  # MANUAL
            data["report_link"] = self._report_link_from_mail
            field_val = self.report_value_var.get().strip()
            data["manual_input_file"] = field_val

            import os
            if not field_val:
                missing.append("manual_input_file (downloaded path missing)")
            elif not os.path.exists(field_val):
                missing.append("manual_input_file (downloaded file not found on disk)")

        if missing:
            messagebox.showwarning(
                "TriWorX",
                "Missing required fields:\n- " + "\n- ".join(missing)
            )
            return

        self.on_register_callback(data)
        messagebox.showinfo("TriWorX", "Execution registered successfully.")