import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
import os
import subprocess
import sys


from triworx.ui.mail_intake import MailIntakePanel
from triworx.core.stage_engine import StageEngine
from tools_pipeline.Stage2_Tools.triage_flow.html_report import download_html_evidence

import requests   # already there OR add if missing

BASE_URL = "https://jira.devops.jlr-apps.com"
JIRA_TOKEN = "MTI1NDQ4OTAzMjcwOtB3+hkVhMEJjt/kXxXnXXZioVtF"
CERT_PATH = r"C:\\cert\\jira_allcert.pem"


def fetch_sw_details_from_jira(test_execution_id):
    try:
        url = f"{BASE_URL}/rest/api/2/issue/{test_execution_id}"

        response = requests.get(
            url,
            headers={
                "Authorization": f"Bearer {JIRA_TOKEN}",
                "Accept": "application/json"
            },
            params={"fields": "fixVersions,labels"},   # include labels
            verify=CERT_PATH
        )

        if response.status_code != 200:
            print("Jira fetch failed:", response.status_code)
            return "", ""

        data = response.json()
        fields = data.get("fields", {})

        # SW Version (Fix Versions)
        fix_versions = fields.get("fixVersions", [])
        sw_version = fix_versions[0].get("name", "") if fix_versions else ""

        # SW Component (Labels)
        labels = fields.get("labels", [])
        sw_component = ",".join(labels) if labels else ""

        return sw_version, sw_component

    except Exception as e:
        print("Error fetching SW details:", e)

    return "", ""

class TriWorXGUI:
    def __init__(self, root):
        self.root = root
        self.root.main_gui = self
        self.root.title("TriWorX – Stage 1: Test Execution Data Extraction & SIMS Enrichment")

        self.execution_context = None
        self.stage_engine = None

        self.mail_intake = MailIntakePanel(self.root, self.on_execution_registered)

        self.status_lbl = tk.Label(self.root, text="No execution registered")
        self.status_lbl.pack(fill="x", pady=5)
    
        # -------------------------
        # Stage-1 button (unchanged behavior)
        # -------------------------
        tk.Button(
            self.root,
            text="Execute Stage‑1",
            command=self.execute_stage_1
        ).pack(pady=4)

    def _open_stage2_window(self):
        exec_ctx = self.execution_context["execution"]

        win = tk.Toplevel(self.root)
        exec_id = exec_ctx.get("test_execution_id", "UNKNOWN")

        win.title(f"TriWorX – Stage 2: {exec_id}")
        win.geometry("600x220")

        frame = tk.LabelFrame(win, text="Stage‑2: Update L0 Triage Analysis", padx=10, pady=10)
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        # ✅ Execution ID label
        tk.Label(
            frame,
            text=f"Execution ID: {exec_id}",
            font=("Arial", 10, "bold")
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 10))

        # ✅ Framework
        tk.Label(frame, text="Framework").grid(row=1, column=0, sticky="w")

        framework_var = tk.StringVar(value="FLOW")

        ttk.Combobox(
            frame,
            textvariable=framework_var,
            values=["FLOW"],
            state="readonly",
            width=25
        ).grid(row=1, column=1, sticky="w")

        # ✅ Report label + input
        tk.Label(frame, text="Flow report (.html)").grid(row=2, column=0, sticky="w")

        report_var = tk.StringVar()

        frame.columnconfigure(1, weight=1)

        report_entry = tk.Entry(frame, textvariable=report_var, width=90, justify="left")
        report_entry.grid(row=2, column=1, sticky="we")

        # ✅ Browse button

        def browse():
            path = filedialog.askopenfilename(filetypes=[("HTML files", "*.html")])
            if path:
                report_var.set(path)                
                report_entry.delete(0, tk.END)
                report_entry.insert(0, path)
                report_entry.xview_moveto(1)
                print(report_var.get())


        tk.Button(frame, text="Browse", command=browse).grid(row=2, column=2)

        # ✅ Stage‑2 execution
        def run_stage2():
            report_path = report_var.get()

            if not report_path or not os.path.exists(report_path):
                messagebox.showwarning("Stage‑2", "Please select a valid HTML report.")
                return

            excel_file = exec_ctx.get("output_file")

            if not excel_file or not os.path.exists(excel_file):
                messagebox.showerror("Stage‑2 Failed", "Stage‑1 output Excel not found.")
                return

            html_path = report_path

            base, ext = os.path.splitext(excel_file)
            out_file = base + "_stage2" + ext

            te = exec_ctx.get("test_execution_id", "UNKNOWN")

            log_path = os.path.join(
                r"C:\\JLR\\Tools\\TriWorX_Full\\logs",
                f"stage2_flow_{te}.log"
            )

            summary_path = os.path.join(
                r"C:\\JLR\\Tools\\TriWorX_Full\\logs",
                f"stage2_flow_summary_{te}.json"
            )

            cmd = [
                sys.executable,
                "tools_pipeline/Stage2_Tools/triworx_stage2_flow_entry.py",
                "--excel", excel_file,
                "--report", html_path,
                "--out", out_file,
                "--log", log_path,
                "--summary", summary_path,
                "--verdict-sheet", te
            ]

            print("[UI] EXEC STAGE-2 CMD:", cmd)

            try:
                result = subprocess.run(cmd, capture_output=True, text=True)

                print(result.stdout)
                print(result.stderr)

                if result.returncode != 0:
                    raise Exception(result.stderr or "Stage‑2 failed")

                messagebox.showinfo("Stage‑2", "L0 Triage updated successfully ✅")

            except Exception as e:
                messagebox.showerror("Stage‑2 Failed", str(e))

        # ✅ Button LAST
        tk.Button(
            frame,
            text="Update L0 Triage",
            command=run_stage2
        ).grid(row=3, column=1, pady=10)

    # # -------------------------
    # # Stage-2 UI
    # # -------------------------
    # def _build_stage2_ui(self):
    #     self.stage2_frame = tk.LabelFrame(self.root, text="Stage‑2: Update L0 Triage", padx=8, pady=8)
    #     self.stage2_frame.pack(fill="x", padx=8, pady=8)

    #     self.stage2_status_var = tk.StringVar(value="Stage‑2 locked. Complete Stage‑1 first.")
    #     tk.Label(self.stage2_frame, textvariable=self.stage2_status_var).grid(
    #         row=0, column=0, columnspan=3, sticky="w"
    #     )

    #     # Framework (Flow supported now)
    #     tk.Label(self.stage2_frame, text="Framework").grid(row=1, column=0, sticky="w")
    #     self.stage2_framework_var = tk.StringVar(value="FLOW")
    #     self.stage2_framework_cb = ttk.Combobox(
    #         self.stage2_frame,
    #         textvariable=self.stage2_framework_var,
    #         values=["FLOW", "ATS (coming soon)", "KDT (coming soon)"],
    #         state="readonly",
    #         width=24
    #     )
    #     self.stage2_framework_cb.grid(row=1, column=1, sticky="w")

    #     # Report HTML file (single file selection for Flow)
    #     tk.Label(self.stage2_frame, text="Flow report (.html)").grid(row=2, column=0, sticky="w")
    #     self.stage2_report_var = tk.StringVar(value="")
    #     self.stage2_report_entry = tk.Entry(self.stage2_frame, textvariable=self.stage2_report_var, width=70)
    #     self.stage2_report_entry.grid(row=2, column=1, sticky="w")

    #     self.stage2_browse_btn = tk.Button(self.stage2_frame, text="Browse", command=self._browse_stage2_report)
    #     self.stage2_browse_btn.grid(row=2, column=2, padx=4)

    #     # Update L0 Triage (Stage-2 execute)
    #     self.stage2_run_btn = tk.Button(
    #         self.stage2_frame,
    #         text="Update L0 Triage",
    #         command=self.execute_stage_2
    #     )
    #     self.stage2_run_btn.grid(row=3, column=1, sticky="e", pady=6)

    #     # Manual offline completion
    #     self.stage2_manual_done_btn = tk.Button(
    #         self.stage2_frame,
    #         text="Mark Stage‑2 Completed (Manual)",
    #         command=self.mark_stage2_completed
    #     )
    #     self.stage2_manual_done_btn.grid(row=3, column=2, sticky="e", pady=6)

    # def _set_stage2_enabled(self, enabled: bool):
    #     state = "normal" if enabled else "disabled"
    #     self.stage2_framework_cb.config(state=("readonly" if enabled else "disabled"))
    #     self.stage2_report_entry.config(state=state)
    #     self.stage2_browse_btn.config(state=state)
    #     self.stage2_run_btn.config(state=state)
    #     self.stage2_manual_done_btn.config(state=state)

    # def _browse_stage2_report(self):
    #     path = filedialog.askopenfilename(
    #         title="Select Flow HTML report",
    #         filetypes=[("HTML files", "*.html"), ("All files", "*.*")]
    #     )
    #     if path:
    #         self.stage2_report_var.set(path)

    # -------------------------
    # Existing Intake population (unchanged)
    # -------------------------
    def populate_intake_from_mail(self, mail_input: dict):
        sanitized = dict(mail_input)

        DEFAULT_SW_VERSION = "DADC_Drop11.2_master_26.20.16"
        sw = sanitized.get("sw_version", "")

        if isinstance(sw, dict):
            sw = sw.get("value", "")
        if sw is None:
            sw = ""
        if not str(sw).strip():
            sw = DEFAULT_SW_VERSION

        sanitized["sw_version"] = sw

        if not sanitized.get("template_path"):
            sanitized["template_path"] = (
                "templates/L0_Triage_Report_XX_XX_XXXX_"
                "TP_AADT-XXXXXX_TE_AADT-XXXXXX.xlsx"
            )

        for k, v in sanitized.items():
            if v is None:
                sanitized[k] = ""

        self.mail_intake.populate_from_mail(sanitized)

    # -------------------------
    # Register execution (unchanged behavior)
    # -------------------------
    def on_execution_registered(self, mail_data: dict):

        print("REGISTER CALLED")

        test_execution_id = mail_data.get("test_execution_id", "").strip()

        # Fetch from Jira
        sw_version, sw_component = fetch_sw_details_from_jira(test_execution_id)

        if sw_version:
            print(f"[DEBUG] SW Version from Jira: {sw_version}")
            mail_data["sw_version"] = sw_version

        if sw_component:
            print(f"[DEBUG] SW Component from Jira (labels): {sw_component}")
            mail_data["sw_component"] = sw_component
        
        
        self.execution_context = {"execution": mail_data}
        self.mail_intake.populate_from_mail(mail_data)
        self.stage_engine = StageEngine(self.execution_context)


    # -------------------------
    # Stage-1 execution (safe: try/except + enables Stage-2 on success)
    # -------------------------
    def execute_stage_1(self):
        print("execution_context =", self.execution_context)
        if not self.execution_context:
            messagebox.showwarning("TriWorX", "Register an execution first.")
            return

        exec_ctx = self.execution_context["execution"]
        exec_type = (exec_ctx.get("execution_type") or "").strip().upper()

        # --- Hard guards for MANUAL ---
        if exec_type == "MANUAL":
            mfile = (exec_ctx.get("manual_input_file") or "").strip()
            if not mfile or not os.path.exists(mfile):
                messagebox.showwarning(
                    "TriWorX – Manual Stage‑1",
                    "Stage‑1 cannot start because manual_input_file is missing.\n\n"
                    "Please ensure the manual file is downloaded/resolved and registered.\n"
                    f"Current value: {mfile}"
                )
                return

        # --- Hard guards for template/output ---
        tpath = (exec_ctx.get("template_path") or "").strip()
        if not tpath:
            messagebox.showerror("TriWorX", "template_path is empty. Cannot run Stage‑1.")
            return

        ofile = (exec_ctx.get("output_file") or "").strip()
        if not ofile:
            messagebox.showerror("TriWorX", "output_file is empty. Cannot run Stage‑1.")
            return

        try:
            self.stage_engine.execute_stage(1)

            exec_ctx = self.execution_context["execution"]
            exec_type = (exec_ctx.get("execution_type") or "").strip().upper()
            
            # ---------------------------------------------------
            # HTML REPORT DOWNLOAD - ONLY FOR AUTOMATED EXECUTION
            # ---------------------------------------------------
            if exec_type == "AUTOMATED":

                print("DEBUG: AUTOMATED execution → batch HTML download")

                import json

                test_execution_ids = exec_ctx.get("test_execution_ids") or [exec_ctx.get("test_execution_id")]

                # FIX: initialize FIRST
                self._prepare_stage2_defaults()

                exec_ctx.setdefault("stage2", {})
                exec_ctx["stage2"]["flow_report_paths"] = []

                base_output = exec_ctx.get("output_file", "")

                for te_id in test_execution_ids:

                    print(f"DEBUG: Processing TE → {te_id}")

                    meta_path = base_output.replace(
                        f"TE_{exec_ctx.get('test_execution_id')}",
                        f"TE_{te_id}"
                    ).replace(".xlsx", "_meta.json")

                    print("DEBUG: Looking for meta file:", meta_path)

                    if not os.path.exists(meta_path):
                        raise Exception(f"Meta file not found for {te_id}")

                    with open(meta_path, "r") as f:
                        meta = json.load(f)

                    evidence_links = meta.get("evidence_links", [])

                    download_dir = os.path.join(
                        "C:\\JLR\\Tools\\TriWorX_Full\\stage2_reports",
                        te_id
                    )

                    html_files = download_html_evidence(
                        evidence_links,
                        download_dir,
                        te_id
                    )

                    if not html_files:
                        raise Exception(f"HTML download failed for {te_id}")

                    exec_ctx["stage2"]["flow_report_paths"].append(html_files[0])

                # required for Stage‑2
                exec_ctx["stage2"]["flow_report_path"] = exec_ctx["stage2"]["flow_report_paths"][0]

                # enable UI AFTER all setup
                self._open_stage2_window()
                
                messagebox.showinfo(
                    "Stage‑1 Completed",
                    f"{len(test_execution_ids)} HTML reports ready.\nOpening Stage‑2..."
                )

            # -----------------------------
            # MANUAL EXECUTION (SKIP EVERYTHING)
            # -----------------------------
            else:
                print("DEBUG: MANUAL execution → skipping meta + download")
                # self._set_stage2_enabled(False)
                messagebox.showinfo(
                    "Stage‑1 Completed",
                    "Manual execution.\nSkipping Stage‑2 → Proceeding to Stage‑3."
                )
                self._execute_stage_3()
            

        except Exception as e:
            messagebox.showerror("TriWorX – Stage‑1 Failed", str(e))
    # -------------------------
    # Stage-2 defaults (paths and status)
    # -------------------------
    def _prepare_stage2_defaults(self):
        exec_ctx = self.execution_context["execution"]
        exec_ctx.setdefault("stage2", {})

        out1 = exec_ctx.get("output_file", "")
        base, ext = os.path.splitext(out1) if out1 else ("", ".xlsx")

        exec_ctx["stage2"].setdefault("framework", "FLOW")
        exec_ctx["stage2"].setdefault("out_file", base + "_stage2" + ext)
        project_root = r"C:\\JLR\\Tools\\TriWorX_Full"   # baseline constant
        te = exec_ctx.get("test_execution_id","UNKNOWN")
        exec_ctx["stage2"]["log_path"] = os.path.join(project_root, "logs", f"stage2_flow_{te}.log")
        exec_ctx["stage2"]["summary_path"] = os.path.join(project_root, "logs", f"stage2_flow_summary_{te}.json")

        exec_ctx["stage2"].setdefault("verdict_sheet", exec_ctx.get("test_execution_id", ""))
        exec_ctx["stage2"].setdefault("status", "PENDING")

    # -------------------------
    # Stage-2 execution (Update L0 Triage)
    # -------------------------
    # def execute_stage_2(self):
    #     if not self.execution_context:
    #         return

    #     exec_ctx = self.execution_context["execution"]
    #     exec_type = (exec_ctx.get("execution_type") or "").strip().upper()

    #     exec_ctx.setdefault("stage2", {})
    #     self._prepare_stage2_defaults()

    #     # Manual: offline-managed
    #     if exec_type == "MANUAL":
    #         messagebox.showinfo(
    #             "Stage‑2 (Manual)",
    #             "Manual executions are updated offline.\n"
    #             "After completing offline update, click 'Mark Stage‑2 Completed (Manual)'."
    #         )
    #         return

    #     # Automated: Flow supported now
    #     fw = (self.stage2_framework_var.get() or "").strip().upper()
    #     if not fw.startswith("FLOW"):
    #         messagebox.showwarning("Stage‑2", "Only FLOW is supported for now (ATS/KDT coming soon).")
    #         return

    #     report_path = (self.stage2_report_var.get() or "").strip()
    #     if not report_path or not os.path.exists(report_path):
    #         messagebox.showwarning("Stage‑2", "Please select a valid Flow HTML report file.")
    #         return

    #     exec_ctx["stage2"]["framework"] = "FLOW"
    #     exec_ctx["stage2"]["flow_report_path"] = report_path
    #     exec_ctx["stage2"]["status"] = "RUNNING"

    #     try:
    #         # This requires STAGE_TOOL_MAP[2] configured in stage_tool_registry.py
    #         self.stage_engine.execute_stage(2)

    #         exec_ctx["stage2"]["status"] = "COMPLETED"
    #         self.stage2_status_var.set("Stage‑2 COMPLETED: L0 triage updated")

    #         messagebox.showinfo(
    #             "Stage‑2 Completed",
    #             f"Update L0 Triage completed.\n\nOutput:\n{exec_ctx['stage2'].get('out_file','')}"
    #         )

    #     except Exception as e:
    #         exec_ctx["stage2"]["status"] = "FAILED"
    #         messagebox.showerror("TriWorX – Stage‑2 Failed", str(e))

    def execute_stage_2(self, report_path):
        exec_ctx = self.execution_context["execution"]

        exec_ctx.setdefault("stage2", {})
        exec_ctx["stage2"]["flow_report_path"] = report_path

        try:
            self.stage_engine.execute_stage(2)
            messagebox.showinfo("Stage‑2", "L0 Triage updated successfully ✅")
        except Exception as e:
            messagebox.showerror("Stage‑2 Failed", str(e))

    # -------------------------
    # Manual offline completion marker
    # -------------------------
    # def mark_stage2_completed(self):
    #     if not self.execution_context:
    #         return
    #     exec_ctx = self.execution_context["execution"]
    #     exec_ctx.setdefault("stage2", {})
    #     exec_ctx["stage2"]["status"] = "COMPLETED"
    #     self.stage2_status_var.set("Stage‑2 COMPLETED (Manual offline update)")
    #     messagebox.showinfo("Stage‑2", "Stage‑2 marked as completed.")