from triworx.registry.stage_tool_registry import (
    TOOLS_REGISTRY,
    STAGE_TOOL_MAP
)
from triworx.tools.cli_executor import run_cli_tool
from triworx.tools.verifier import verify_outputs

import os
import shutil


class StageEngine:
    """
    Executes and verifies tools associated with a workflow stage.
    """

    def __init__(self, execution_context):
        self.execution_context = execution_context

    def execute_stage(self, stage_number: int):
        exec_ctx = self.execution_context["execution"]

        # =================================================
        # ✅ STAGE‑1: HARD INPUT NORMALIZATION
        # =================================================
        if stage_number == 1:
            raw_sw = exec_ctx.get("sw_version")

            # ---------- Normalize SW version ----------
            if isinstance(raw_sw, dict):
                raw_sw = raw_sw.get("value", "")


            if not isinstance(raw_sw, str) or not raw_sw.strip():
                raise RuntimeError(
                    "StageEngine: SW Version is missing. It must be fetched from Jira Fix Versions."
                )


            exec_ctx["sw_version"] = raw_sw
            print(f"[StageEngine] Normalized sw_version => {raw_sw}")

            # ---------- Normalize SW component ----------
            raw_comp = exec_ctx.get("sw_component")

            if isinstance(raw_comp, dict):
                raw_comp = raw_comp.get("value", "")

            if not isinstance(raw_comp, str) or not raw_comp.strip():
                raise RuntimeError(
                    "StageEngine: SW Component is missing. It must be fetched from Jira Labels."
                )

            exec_ctx["sw_component"] = raw_comp
            print(f"[StageEngine] Normalized sw_component => {raw_comp}")


            # ---------- ✅ FINAL output file handling ----------
            output_file = exec_ctx.get("output_file")
            print("[STAGEENGINE] using output_file =", exec_ctx["output_file"])
            if not output_file:
                raise RuntimeError(
                    "StageEngine: output_file must be defined before execution"
                )

            template_path = exec_ctx["template_path"]

            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_file), exist_ok=True)

            # Always overwrite the SAME file
            shutil.copy(template_path, output_file)

            print(f"[StageEngine] Using output file: {output_file}")

        # =================================================
        # Execute registered tools for this stage
        # =================================================
        tool_ids = STAGE_TOOL_MAP.get(stage_number, [])
        for tool_id in tool_ids:
            tool_def = TOOLS_REGISTRY[tool_id]
            run_cli_tool(tool_def, self.execution_context)

    def verify_stage(self, stage_number: int) -> bool:
        tool_ids = STAGE_TOOL_MAP.get(stage_number, [])
        for tool_id in tool_ids:
            tool_def = TOOLS_REGISTRY[tool_id]
            if not verify_outputs(tool_def, self.execution_context):
                return False
        return True