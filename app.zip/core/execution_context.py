class ExecutionContext(dict):
    @classmethod
    def from_mail_input(cls, data: dict):
        return cls({
            "execution": {
                "test_plan_id": data["test_plan_id"],
                "test_execution_id": data["test_execution_id"],
                "execution_type": data["execution_type"],
                "rig_id": data["rig_id"],
                "sw_version": data["sw_version"],
                "sw_component": data["sw_component"],

                # ✅ must be here
                "manual_input_file": data.get("manual_input_file", ""),

                "report_link": data.get("report_link", ""),
                "template_path": data["template_path"],
                "output_file": data["output_file"],
            }
        })