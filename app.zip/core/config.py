import os

class TriWorXConfig:
    def __init__(self):
        self.jira_base_url = os.environ.get("TRIWORX_JIRA_BASE_URL", "https://jira.devops.jlr-apps.com")
        self.jira_pat = (os.environ.get("TRIWORX_JIRA_PAT") or "").strip()
        self.jira_pem = (os.environ.get("TRIWORX_JIRA_PEM") or "").strip()
        self.download_dir = os.environ.get("TRIWORX_DOWNLOAD_DIR", os.path.join(os.path.expanduser("~"), "Downloads"))

    def require_jira(self):
        if not self.jira_pat:
            raise RuntimeError("TRIWORX_JIRA_PAT is not set (required for Jira operations).")