
import subprocess
import sys
import re   # ✅ REQUIRED for sw_version validation


# -------------------------------------------------
# ✅ RESOLVE SCRIPT ENTRYPOINT
# -------------------------------------------------
def _resolve_tool_script(tool_def: dict) -> str:
    """
    Resolve script/executable path from tool definition.
    Supports TriWorX registry layout.
    """

    # ✅ PRIMARY: TriWorX registry
    if "entrypoint" in tool_def:
        return tool_def["entrypoint"]

    # Fallbacks
    if "script" in tool_def:
        return tool_def["script"]

    if "executable" in tool_def:
        return tool_def["executable"]

    if "cmd" in tool_def and isinstance(tool_def["cmd"], (list, tuple)):
        return tool_def["cmd"][0]

    raise KeyError(
        f"Tool definition does not contain a supported entrypoint: {tool_def}"
    )


# -------------------------------------------------
# ✅ RESOLVE ARGUMENT MAP
# -------------------------------------------------
def _resolve_tool_args(tool_def: dict) -> dict:
    if "args" in tool_def:
        return tool_def["args"]

    if "arguments" in tool_def:
        return tool_def["arguments"]

    return {}


# -------------------------------------------------
# ✅ RESOLVE DOTTED CONTEXT PATHS
# -------------------------------------------------
def _resolve_ctx_value(execution_context: dict, path: str):
    """
    Resolve dotted execution paths like:
    'execution.test_plan_id'
    """
    cur = execution_context
    for part in path.split("."):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


# -------------------------------------------------
# ✅ MAIN CLI EXECUTOR
# -------------------------------------------------
def run_cli_tool(tool_def, execution_context):
    """
    Executes a CLI tool with fully normalized execution arguments.
    Final safety boundary before external tools.
    """

    script = _resolve_tool_script(tool_def)
    arg_map = _resolve_tool_args(tool_def)

    cmd = [sys.executable, script]

    for cli_arg, ctx_path in arg_map.items():
        val = _resolve_ctx_value(execution_context, ctx_path)

        # -------------------------------
        # Normalize structured values
        # -------------------------------
        if isinstance(val, dict):
            val = val.get("value", "")

        # Convert everything to string for checks
        val_str = str(val).strip() if val is not None else ""

        # -------------------------------
        # ✅ FINAL sw_version VALIDATION
        # -------------------------------
        if cli_arg == "--sw_version":
            # Accept ONLY valid DropX.Y patterns
            if not re.search(r"Drop\d+\.\d+", val_str):
                val_str = "DADC_Drop11.2_master_26.20.16"
                print(
                    "[CLI Executor] Invalid or missing sw_version — "
                    "forced to default: DADC_Drop11.2_master_26.20.16"
                )

        if val_str:
            cmd.extend([cli_arg, val_str])

    print("[TriWorX] EXEC CMD:", cmd)


    result = subprocess.run(
        cmd,
        stdout=sys.stdout,
        stderr=sys.stderr,
        text=True
    )

    if result.returncode != 0:
        raise RuntimeError(f"Tool failed with exit code {result.returncode}")
