import os

def _resolve(ctx, dotted):
    for part in dotted.split("."):
        ctx = ctx[part]
    return ctx

def verify_outputs(tool, context):
    for rule in tool.get("outputs", []):
        if rule["type"] == "file":
            path = _resolve(context, rule["path"])
            if not os.path.exists(path):
                return False
            if os.path.getsize(path) == 0:
                return False
    return True