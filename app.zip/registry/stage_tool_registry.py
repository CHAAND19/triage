# triworx/registry/stage_tool_registry.py

TOOLS_REGISTRY = {
    "triage_stage1": {
        "entrypoint": "tools_pipeline/Stage1_Tools/Triage_GUI_Wrapper.py",
        "arguments": {
            "--test_plan": "execution.test_plan_id",
            "--test_execution": "execution.test_execution_id",
            "--execution_type": "execution.execution_type",
            "--rig_id": "execution.rig_id",
            "--sw_version": "execution.sw_version",
            "--sw_component": "execution.sw_component",
            "--template_file": "execution.template_path",

            "--manual_input_file": "execution.manual_input_file",

            # ✅ Output authority = TriWorX → always pass this
            "--output_file": "execution.output_file",
        },

        "outputs": []
    },
    "triage_stage2_flow": {
    "entrypoint": "tools_pipeline/Stage2_Tools/triworx_stage2_flow_entry.py",
    "arguments": {
        "--excel": "execution.output_file",
        "--report": "execution.stage2.flow_report_path",
        "--out": "execution.stage2.out_file",
        "--log": "execution.stage2.log_path",
        "--summary": "execution.stage2.summary_path",
        "--verdict-sheet": "execution.stage2.verdict_sheet",
    },
    "outputs": []
},
}

STAGE_TOOL_MAP = {
    1: ["triage_stage1"],
    2: ["triage_stage2_flow"],  # ✅ new
}
